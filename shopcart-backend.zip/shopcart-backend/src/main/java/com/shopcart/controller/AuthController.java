package com.shopcart.controller;

import com.shopcart.dto.request.LoginRequest;
import com.shopcart.dto.request.SignupRequest;
import com.shopcart.dto.response.ApiResponse;
import com.shopcart.dto.response.LoginResponse;
import com.shopcart.dto.response.UserResponse;
import com.shopcart.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * AuthController
 *
 * Exposes REST endpoints for user authentication:
 *   POST /api/auth/signup  — register a new user account
 *   POST /api/auth/login   — authenticate and receive a session token
 *   POST /api/auth/logout  — invalidate the current session
 *
 * All responses are wrapped in the standard {@link ApiResponse} envelope.
 */
@Slf4j
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    // ── POST /api/auth/signup ──────────────────────────────────────────────

    /**
     * Registers a new user.
     *
     * Request body fields: fullName, email, phone, password
     * Returns: the created user's public profile
     */
    @PostMapping("/signup")
    public ResponseEntity<ApiResponse<UserResponse>> signup(
            @Valid @RequestBody SignupRequest request) {

        log.info("Signup request received for email: {}", request.getEmail());

        UserResponse userResponse = authService.signup(request);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success("Account created successfully. Please login.", userResponse));
    }

    // ── POST /api/auth/login ───────────────────────────────────────────────

    /**
     * Authenticates a user with email and password.
     *
     * Request body fields: email, password
     * Returns: user profile + session token
     */
    @PostMapping("/login")
    public ResponseEntity<ApiResponse<LoginResponse>> login(
            @Valid @RequestBody LoginRequest request) {

        log.info("Login request received for email: {}", request.getEmail());

        LoginResponse loginResponse = authService.login(request);

        return ResponseEntity
                .status(HttpStatus.OK)
                .body(ApiResponse.success("Login successful.", loginResponse));
    }

    // ── POST /api/auth/logout ──────────────────────────────────────────────

    /**
     * Logs out the current user by invalidating their session token.
     *
     * Expects the session token in the X-Session-Token request header.
     */
    @PostMapping("/logout")
    public ResponseEntity<ApiResponse<Void>> logout(
            @RequestHeader(value = "X-Session-Token", required = false) String sessionToken) {

        log.info("Logout request received.");

        authService.logout(sessionToken);

        return ResponseEntity
                .status(HttpStatus.OK)
                .body(ApiResponse.success("Logged out successfully."));
    }
}
