package com.shopcart.controller;

import com.shopcart.dto.request.CategoryRequest;
import com.shopcart.dto.response.ApiResponse;
import com.shopcart.dto.response.CategoryResponse;
import com.shopcart.service.CategoryService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * CategoryController
 *
 * Exposes REST endpoints for product category management:
 *
 *   GET    /api/categories              — list all categories
 *   GET    /api/categories/{id}         — get category with products
 *   POST   /api/categories              — create a category (Admin)
 *   PUT    /api/categories/{id}         — update category name/discount (Admin)
 *   PATCH  /api/categories/{id}/discount — update discount only (Admin)
 *   DELETE /api/categories/{id}         — delete a category (Admin)
 */
@Slf4j
@RestController
@RequestMapping("/api/categories")
@RequiredArgsConstructor
public class CategoryController {

    private final CategoryService categoryService;

    // ── GET /api/categories ────────────────────────────────────────────────

    /**
     * Returns all categories — used to populate the Admin Dashboard
     * category cards and the UserHome filter bubbles.
     */
    @GetMapping
    public ResponseEntity<ApiResponse<List<CategoryResponse>>> getAllCategories() {
        log.debug("Request to fetch all categories.");
        List<CategoryResponse> categories = categoryService.getAllCategories();
        return ResponseEntity.ok(
                ApiResponse.success("Categories fetched successfully.", categories)
        );
    }

    // ── GET /api/categories/{id} ───────────────────────────────────────────

    /**
     * Returns a single category along with its complete product list.
     * Used to populate the Admin Dashboard product table.
     */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<CategoryResponse>> getCategoryById(
            @PathVariable Long id) {

        log.debug("Request to fetch category ID: {}", id);
        CategoryResponse category = categoryService.getCategoryById(id);
        return ResponseEntity.ok(
                ApiResponse.success("Category fetched successfully.", category)
        );
    }

    // ── POST /api/categories ───────────────────────────────────────────────

    /**
     * Creates a new product category.
     * Called from the Admin Dashboard "Add Category" form.
     */
    @PostMapping
    public ResponseEntity<ApiResponse<CategoryResponse>> createCategory(
            @Valid @RequestBody CategoryRequest request) {

        log.info("Admin request to create category: {}", request.getName());
        CategoryResponse created = categoryService.createCategory(request);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success("Category created successfully.", created));
    }

    // ── PUT /api/categories/{id} ───────────────────────────────────────────

    /**
     * Updates a category's name and/or discount.
     * Called from the Admin Dashboard "Category Settings" form.
     */
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<CategoryResponse>> updateCategory(
            @PathVariable Long id,
            @Valid @RequestBody CategoryRequest request) {

        log.info("Admin request to update category ID: {}", id);
        CategoryResponse updated = categoryService.updateCategory(id, request);
        return ResponseEntity.ok(
                ApiResponse.success("Category updated successfully.", updated)
        );
    }

    // ── PATCH /api/categories/{id}/discount ────────────────────────────────

    /**
     * Updates only the discount percentage of an existing category.
     * Supports the Admin Dashboard "Update Discount" action.
     *
     * Request body: { "discount": "25%" }
     */
    @PatchMapping("/{id}/discount")
    public ResponseEntity<ApiResponse<CategoryResponse>> updateDiscount(
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {

        String discount = body.get("discount");
        log.info("Admin request to update discount for category ID: {} to {}", id, discount);

        CategoryResponse updated = categoryService.updateDiscount(id, discount);
        return ResponseEntity.ok(
                ApiResponse.success("Discount updated successfully.", updated)
        );
    }

    // ── DELETE /api/categories/{id} ────────────────────────────────────────

    /**
     * Deletes a category and all its associated products.
     * Called from the Admin Dashboard "Delete Category" button.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteCategory(
            @PathVariable Long id) {

        log.info("Admin request to delete category ID: {}", id);
        categoryService.deleteCategory(id);
        return ResponseEntity.ok(
                ApiResponse.success("Category deleted successfully.")
        );
    }
}
