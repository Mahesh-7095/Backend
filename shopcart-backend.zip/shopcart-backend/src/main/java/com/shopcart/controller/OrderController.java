package com.shopcart.controller;

import com.shopcart.dto.request.OrderRequest;
import com.shopcart.dto.response.ApiResponse;
import com.shopcart.dto.response.OrderResponse;
import com.shopcart.model.Order;
import com.shopcart.service.OrderService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * OrderController
 *
 * Exposes REST endpoints for order management:
 *
 *   POST  /api/orders                        — place a new order (User: Payment page)
 *   GET   /api/orders/user/{userId}          — get all orders for a user (User: Dashboard)
 *   GET   /api/orders/{orderId}              — get a specific order by ID
 *   GET   /api/orders                        — get all orders (Admin)
 *   PATCH /api/orders/{orderId}/status       — update order status (Admin)
 */
@Slf4j
@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;

    // ── POST /api/orders ───────────────────────────────────────────────────

    /**
     * Places a new order after payment confirmation.
     * Called by Payment.js after the user clicks "Complete Payment".
     *
     * Request body: userId, items[], totalAmount, paymentMethod
     */
    @PostMapping
    public ResponseEntity<ApiResponse<OrderResponse>> placeOrder(
            @Valid @RequestBody OrderRequest request) {

        log.info("Order placement request for user ID: {}", request.getUserId());
        OrderResponse order = orderService.placeOrder(request);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success("Order placed successfully.", order));
    }

    // ── GET /api/orders/user/{userId} ──────────────────────────────────────

    /**
     * Returns all orders belonging to a specific user, sorted newest first.
     * Called by the "My Orders" tab in UserDashboard.js.
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<ApiResponse<List<OrderResponse>>> getOrdersByUser(
            @PathVariable Long userId) {

        log.debug("Fetching orders for user ID: {}", userId);
        List<OrderResponse> orders = orderService.getOrdersByUser(userId);
        return ResponseEntity.ok(
                ApiResponse.success("Orders fetched successfully.", orders)
        );
    }

    // ── GET /api/orders/{orderId} ──────────────────────────────────────────

    /**
     * Returns the details of a single order including all its line items.
     */
    @GetMapping("/{orderId}")
    public ResponseEntity<ApiResponse<OrderResponse>> getOrderById(
            @PathVariable Long orderId) {

        log.debug("Fetching order ID: {}", orderId);
        OrderResponse order = orderService.getOrderById(orderId);
        return ResponseEntity.ok(
                ApiResponse.success("Order fetched successfully.", order)
        );
    }

    // ── GET /api/orders ────────────────────────────────────────────────────

    /**
     * Returns all orders across the platform.
     * Intended for Admin Dashboard order management views.
     */
    @GetMapping
    public ResponseEntity<ApiResponse<List<OrderResponse>>> getAllOrders() {
        log.debug("Admin request to fetch all orders.");
        List<OrderResponse> orders = orderService.getAllOrders();
        return ResponseEntity.ok(
                ApiResponse.success("All orders fetched successfully.", orders)
        );
    }

    // ── PATCH /api/orders/{orderId}/status ─────────────────────────────────

    /**
     * Updates the fulfillment status of an order.
     * Called from the Admin Dashboard order management panel.
     *
     * Request body: { "status": "SHIPPED" }
     * Valid values: PROCESSING | SHIPPED | DELIVERED | CANCELLED
     */
    @PatchMapping("/{orderId}/status")
    public ResponseEntity<ApiResponse<OrderResponse>> updateOrderStatus(
            @PathVariable Long orderId,
            @RequestBody Map<String, String> body) {

        String statusStr = body.get("status");
        log.info("Admin request to update order ID: {} to status: {}", orderId, statusStr);

        Order.OrderStatus status;
        try {
            status = Order.OrderStatus.valueOf(statusStr.toUpperCase());
        } catch (IllegalArgumentException e) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.failure(
                            "Invalid status value. Allowed: PROCESSING, SHIPPED, DELIVERED, CANCELLED"
                    ));
        }

        OrderResponse updated = orderService.updateOrderStatus(orderId, status);
        return ResponseEntity.ok(
                ApiResponse.success("Order status updated to " + status + ".", updated)
        );
    }
}
