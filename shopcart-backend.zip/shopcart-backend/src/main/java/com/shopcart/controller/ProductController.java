package com.shopcart.controller;

import com.shopcart.dto.request.ProductRequest;
import com.shopcart.dto.response.ApiResponse;
import com.shopcart.dto.response.ProductResponse;
import com.shopcart.service.ProductService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * ProductController
 *
 * Exposes REST endpoints for product catalog management:
 *
 *   GET    /api/products             — fetch all products (User: home page)
 *   GET    /api/products/{id}        — fetch a single product by ID
 *   GET    /api/products/category/{categoryId} — fetch by category
 *   GET    /api/products/search?keyword= — keyword search
 *   POST   /api/products             — create a product (Admin)
 *   PUT    /api/products/{id}        — update a product (Admin)
 *   DELETE /api/products/{id}        — delete a product (Admin)
 */
@Slf4j
@RestController
@RequestMapping("/api/products")
@RequiredArgsConstructor
public class ProductController {

    private final ProductService productService;

    // ── GET /api/products ──────────────────────────────────────────────────

    /**
     * Returns the full product catalog.
     * Called by UserHome.js on page load to render the product grid.
     */
    @GetMapping
    public ResponseEntity<ApiResponse<List<ProductResponse>>> getAllProducts() {
        log.debug("Request to fetch all products.");
        List<ProductResponse> products = productService.getAllProducts();
        return ResponseEntity.ok(
                ApiResponse.success("Products fetched successfully.", products)
        );
    }

    // ── GET /api/products/{id} ─────────────────────────────────────────────

    /**
     * Returns a single product by its database ID.
     */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ProductResponse>> getProductById(
            @PathVariable Long id) {

        log.debug("Request to fetch product ID: {}", id);
        ProductResponse product = productService.getProductById(id);
        return ResponseEntity.ok(
                ApiResponse.success("Product fetched successfully.", product)
        );
    }

    // ── GET /api/products/category/{categoryId} ────────────────────────────

    /**
     * Returns all products belonging to a specific category.
     * Supports the category filter bubbles in UserHome.js.
     */
    @GetMapping("/category/{categoryId}")
    public ResponseEntity<ApiResponse<List<ProductResponse>>> getProductsByCategory(
            @PathVariable Long categoryId) {

        log.debug("Request to fetch products for category ID: {}", categoryId);
        List<ProductResponse> products = productService.getProductsByCategory(categoryId);
        return ResponseEntity.ok(
                ApiResponse.success("Products fetched by category successfully.", products)
        );
    }

    // ── GET /api/products/search ───────────────────────────────────────────

    /**
     * Searches products by a keyword against name and category.
     * Supports the search bar in UserHome.js.
     */
    @GetMapping("/search")
    public ResponseEntity<ApiResponse<List<ProductResponse>>> searchProducts(
            @RequestParam String keyword) {

        log.debug("Search request with keyword: '{}'", keyword);
        List<ProductResponse> results = productService.searchProducts(keyword);
        return ResponseEntity.ok(
                ApiResponse.success("Search completed.", results)
        );
    }

    // ── POST /api/products ─────────────────────────────────────────────────

    /**
     * Creates a new product under a given category.
     * Called by the Admin Dashboard product form.
     */
    @PostMapping
    public ResponseEntity<ApiResponse<ProductResponse>> createProduct(
            @Valid @RequestBody ProductRequest request) {

        log.info("Admin request to create product: {}", request.getName());
        ProductResponse created = productService.createProduct(request);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success("Product created successfully.", created));
    }

    // ── PUT /api/products/{id} ─────────────────────────────────────────────

    /**
     * Updates an existing product's details.
     * Called by the Admin Dashboard update form.
     */
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<ProductResponse>> updateProduct(
            @PathVariable Long id,
            @Valid @RequestBody ProductRequest request) {

        log.info("Admin request to update product ID: {}", id);
        ProductResponse updated = productService.updateProduct(id, request);
        return ResponseEntity.ok(
                ApiResponse.success("Product updated successfully.", updated)
        );
    }

    // ── DELETE /api/products/{id} ──────────────────────────────────────────

    /**
     * Permanently deletes a product from the catalog.
     * Called by the Admin Dashboard delete button.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteProduct(
            @PathVariable Long id) {

        log.info("Admin request to delete product ID: {}", id);
        productService.deleteProduct(id);
        return ResponseEntity.ok(
                ApiResponse.success("Product deleted successfully.")
        );
    }
}
