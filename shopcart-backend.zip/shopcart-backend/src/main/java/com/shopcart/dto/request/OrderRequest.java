package com.shopcart.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;
import java.util.List;

/**
 * DTO for placing a new Order.
 * Carries the cart items and payment information from the frontend.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderRequest {

    @NotNull(message = "User ID is required")
    private Long userId;

    @NotEmpty(message = "Order must contain at least one item")
    private List<OrderItemRequest> items;

    @NotNull(message = "Total amount is required")
    @DecimalMin(value = "0.01")
    private BigDecimal totalAmount;

    @NotBlank(message = "Payment method is required")
    private String paymentMethod;

    /**
     * Represents a single item inside an order request.
     */
    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class OrderItemRequest {

        private Long productId;

        @NotBlank(message = "Product name is required")
        private String name;

        private String image;

        @NotNull
        @DecimalMin(value = "0.01")
        private BigDecimal price;

        @NotNull
        @Min(value = 1)
        private Integer quantity;
    }
}
