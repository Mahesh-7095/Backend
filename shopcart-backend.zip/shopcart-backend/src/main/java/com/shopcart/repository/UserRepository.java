package com.shopcart.repository;

import com.shopcart.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * UserRepository
 *
 * Provides data access operations for the {@link User} entity.
 * Extends JpaRepository to inherit standard CRUD and pagination methods.
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    /**
     * Finds a user by their email address.
     * Used for login validation and duplicate-email checks during signup.
     */
    Optional<User> findByEmail(String email);

    /**
     * Checks whether an email address is already registered.
     */
    boolean existsByEmail(String email);

    /**
     * Checks whether a phone number is already registered.
     */
    boolean existsByPhone(String phone);

    /**
     * Returns the total number of registered users (excluding admins).
     */
    @Query("SELECT COUNT(u) FROM User u WHERE u.role = 'USER'")
    long countAllCustomers();
}
