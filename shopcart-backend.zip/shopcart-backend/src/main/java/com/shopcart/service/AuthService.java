package com.shopcart.service;

import com.shopcart.dto.request.LoginRequest;
import com.shopcart.dto.request.SignupRequest;
import com.shopcart.dto.response.LoginResponse;
import com.shopcart.dto.response.UserResponse;

/**
 * AuthService
 *
 * Defines the authentication contract for the ShopCart platform.
 * Handles user registration and credential validation.
 */
public interface AuthService {

    /**
     * Registers a new user account.
     *
     * @param request the signup payload containing user details
     * @return the newly created user's profile
     * @throws com.shopcart.exception.DuplicateResourceException if the email is already registered
     */
    UserResponse signup(SignupRequest request);

    /**
     * Authenticates a user with their email and password.
     *
     * @param request the login payload containing credentials
     * @return a {@link LoginResponse} containing the user's profile and session token
     * @throws com.shopcart.exception.BadRequestException if credentials are invalid
     */
    LoginResponse login(LoginRequest request);

    /**
     * Logs out the user by invalidating their session token.
     *
     * @param sessionToken the token issued at login
     */
    void logout(String sessionToken);
}
