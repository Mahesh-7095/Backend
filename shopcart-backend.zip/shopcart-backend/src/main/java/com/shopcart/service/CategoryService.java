package com.shopcart.service;

import com.shopcart.dto.request.CategoryRequest;
import com.shopcart.dto.response.CategoryResponse;

import java.util.List;

/**
 * CategoryService
 *
 * Defines the business operations available for Categories in the ShopCart platform.
 */
public interface CategoryService {

    /** Retrieves all categories (without their product lists). */
    List<CategoryResponse> getAllCategories();

    /** Retrieves a single category by its ID, including its products. */
    CategoryResponse getCategoryById(Long id);

    /** Creates a new category. */
    CategoryResponse createCategory(CategoryRequest request);

    /** Updates an existing category's name or discount. */
    CategoryResponse updateCategory(Long id, CategoryRequest request);

    /** Deletes a category by its ID. */
    void deleteCategory(Long id);

    /** Updates only the discount field of a category. */
    CategoryResponse updateDiscount(Long id, String discount);
}
