package com.shopcart.service;

import com.shopcart.dto.request.OrderRequest;
import com.shopcart.dto.response.OrderResponse;
import com.shopcart.model.Order;

import java.util.List;

/**
 * OrderService
 *
 * Defines the business operations for Order management in the ShopCart platform.
 */
public interface OrderService {

    /** Places a new order from the user's cart. */
    OrderResponse placeOrder(OrderRequest request);

    /** Retrieves all orders placed by a specific user. */
    List<OrderResponse> getOrdersByUser(Long userId);

    /** Retrieves a single order by its ID. */
    OrderResponse getOrderById(Long orderId);

    /** Retrieves all orders in the system (Admin use). */
    List<OrderResponse> getAllOrders();

    /** Updates the status of an existing order (Admin use). */
    OrderResponse updateOrderStatus(Long orderId, Order.OrderStatus status);
}
