package com.shopcart.service;

import com.shopcart.dto.request.SignupRequest;
import com.shopcart.dto.response.UserResponse;

import java.util.List;
import java.util.Map;

/**
 * UserService
 *
 * Defines business operations for user profile management in ShopCart.
 */
public interface UserService {

    /** Retrieves a user's profile by their ID. */
    UserResponse getUserById(Long id);

    /** Retrieves all registered users (Admin use). */
    List<UserResponse> getAllUsers();

    /** Updates a user's profile information (name, phone, address etc.). */
    UserResponse updateProfile(Long id, SignupRequest request);

    /** Updates only the address fields of a user's profile. */
    UserResponse updateAddress(Long id, Map<String, String> addressFields);

    /** Updates the user's password after verifying the current one. */
    void changePassword(Long id, String currentPassword, String newPassword);

    /** Deletes a user account by ID (Admin use). */
    void deleteUser(Long id);
}
