package com.shopcart.service.impl;

import com.shopcart.dto.request.LoginRequest;
import com.shopcart.dto.request.SignupRequest;
import com.shopcart.dto.response.LoginResponse;
import com.shopcart.dto.response.UserResponse;
import com.shopcart.exception.BadRequestException;
import com.shopcart.exception.DuplicateResourceException;
import com.shopcart.model.User;
import com.shopcart.repository.UserRepository;
import com.shopcart.service.AuthService;
import com.shopcart.util.PasswordUtil;
import com.shopcart.util.SessionUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * AuthServiceImpl
 *
 * Implements the {@link AuthService} interface, orchestrating user registration,
 * login credential validation, and session lifecycle management.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final PasswordUtil passwordUtil;
    private final SessionUtil sessionUtil;

    /**
     * {@inheritDoc}
     *
     * Validates that the email is not already in use, hashes the password,
     * and persists the new user to the database.
     */
    @Override
    @Transactional
    public UserResponse signup(SignupRequest request) {
        log.info("Processing signup request for email: {}", request.getEmail());

        if (userRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException(
                    "An account with email '" + request.getEmail() + "' already exists."
            );
        }

        if (userRepository.existsByPhone(request.getPhone())) {
            throw new DuplicateResourceException(
                    "An account with phone number '" + request.getPhone() + "' already exists."
            );
        }

        String hashedPassword = passwordUtil.hashPassword(request.getPassword());

        User newUser = User.builder()
                .fullName(request.getFullName())
                .email(request.getEmail())
                .phone(request.getPhone())
                .password(hashedPassword)
                .role(User.Role.USER)
                .build();

        User savedUser = userRepository.save(newUser);
        log.info("User registered successfully with ID: {}", savedUser.getId());

        return mapToUserResponse(savedUser);
    }

    /**
     * {@inheritDoc}
     *
     * Looks up the user by email, verifies the password hash,
     * creates a session token, and returns the login response.
     */
    @Override
    @Transactional(readOnly = true)
    public LoginResponse login(LoginRequest request) {
        log.info("Processing login request for email: {}", request.getEmail());

        // Hard-coded admin credentials (simple auth — no Spring Security)
        if ("admin@gmail.com".equals(request.getEmail())
                && "admin123".equals(request.getPassword())) {
            log.info("Admin login successful");
            String adminToken = sessionUtil.createSession(-1L);
            return LoginResponse.builder()
                    .userId(-1L)
                    .fullName("Administrator")
                    .email("admin@gmail.com")
                    .role("ADMIN")
                    .sessionToken(adminToken)
                    .build();
        }

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new BadRequestException("Invalid email or password."));

        if (!passwordUtil.verifyPassword(request.getPassword(), user.getPassword())) {
            log.warn("Invalid password attempt for email: {}", request.getEmail());
            throw new BadRequestException("Invalid email or password.");
        }

        String sessionToken = sessionUtil.createSession(user.getId());
        log.info("Login successful for user ID: {}", user.getId());

        return LoginResponse.builder()
                .userId(user.getId())
                .fullName(user.getFullName())
                .email(user.getEmail())
                .role(user.getRole().name())
                .sessionToken(sessionToken)
                .build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void logout(String sessionToken) {
        sessionUtil.invalidateSession(sessionToken);
        log.info("Session invalidated successfully.");
    }

    // ── Private mapper ─────────────────────────────────────────────────────

    private UserResponse mapToUserResponse(User user) {
        return UserResponse.builder()
                .id(user.getId())
                .fullName(user.getFullName())
                .email(user.getEmail())
                .phone(user.getPhone())
                .role(user.getRole().name())
                .createdAt(user.getCreatedAt())
                .build();
    }
}
