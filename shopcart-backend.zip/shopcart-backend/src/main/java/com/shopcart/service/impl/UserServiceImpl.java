package com.shopcart.service.impl;

import com.shopcart.dto.request.SignupRequest;
import com.shopcart.dto.response.UserResponse;
import com.shopcart.exception.BadRequestException;
import com.shopcart.exception.ResourceNotFoundException;
import com.shopcart.model.User;
import com.shopcart.repository.UserRepository;
import com.shopcart.service.UserService;
import com.shopcart.util.PasswordUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * UserServiceImpl
 *
 * Implements the {@link UserService} interface, managing user profile
 * retrieval, updates, password changes, and admin-level user operations.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordUtil passwordUtil;

    /** {@inheritDoc} */
    @Override
    @Transactional(readOnly = true)
    public UserResponse getUserById(Long id) {
        log.debug("Fetching user profile for ID: {}", id);
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", id));
        return mapToUserResponse(user);
    }

    /** {@inheritDoc} */
    @Override
    @Transactional(readOnly = true)
    public List<UserResponse> getAllUsers() {
        log.debug("Fetching all users (Admin request).");
        return userRepository.findAll()
                .stream()
                .map(this::mapToUserResponse)
                .collect(Collectors.toList());
    }

    /** {@inheritDoc} */
    @Override
    @Transactional
    public UserResponse updateProfile(Long id, SignupRequest request) {
        log.info("Updating profile for user ID: {}", id);

        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", id));

        user.setFullName(request.getFullName());
        user.setPhone(request.getPhone());

        User updated = userRepository.save(user);
        log.info("Profile updated for user ID: {}", id);

        return mapToUserResponse(updated);
    }

    /** {@inheritDoc} */
    @Override
    @Transactional
    public UserResponse updateAddress(Long id, Map<String, String> addressFields) {
        log.info("Updating address for user ID: {}", id);

        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", id));

        if (addressFields.containsKey("address")) user.setAddress(addressFields.get("address"));
        if (addressFields.containsKey("city"))    user.setCity(addressFields.get("city"));
        if (addressFields.containsKey("state"))   user.setState(addressFields.get("state"));
        if (addressFields.containsKey("zipCode")) user.setZipCode(addressFields.get("zipCode"));

        User updated = userRepository.save(user);
        log.info("Address updated for user ID: {}", id);

        return mapToUserResponse(updated);
    }

    /** {@inheritDoc} */
    @Override
    @Transactional
    public void changePassword(Long id, String currentPassword, String newPassword) {
        log.info("Processing password change for user ID: {}", id);

        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", id));

        if (!passwordUtil.verifyPassword(currentPassword, user.getPassword())) {
            throw new BadRequestException("Current password is incorrect.");
        }

        if (newPassword == null || newPassword.length() < 6) {
            throw new BadRequestException("New password must be at least 6 characters.");
        }

        user.setPassword(passwordUtil.hashPassword(newPassword));
        userRepository.save(user);

        log.info("Password changed successfully for user ID: {}", id);
    }

    /** {@inheritDoc} */
    @Override
    @Transactional
    public void deleteUser(Long id) {
        log.info("Deleting user with ID: {}", id);

        if (!userRepository.existsById(id)) {
            throw new ResourceNotFoundException("User", "id", id);
        }

        userRepository.deleteById(id);
        log.info("User deleted: ID {}", id);
    }

    // ── Private mapper ─────────────────────────────────────────────────────

    private UserResponse mapToUserResponse(User user) {
        return UserResponse.builder()
                .id(user.getId())
                .fullName(user.getFullName())
                .email(user.getEmail())
                .phone(user.getPhone())
                .address(user.getAddress())
                .city(user.getCity())
                .state(user.getState())
                .zipCode(user.getZipCode())
                .role(user.getRole().name())
                .createdAt(user.getCreatedAt())
                .build();
    }
}
