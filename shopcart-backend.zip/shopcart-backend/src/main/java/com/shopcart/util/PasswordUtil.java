package com.shopcart.util;

import org.springframework.stereotype.Component;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * PasswordUtil
 *
 * Provides a secure, salted SHA-256 hashing mechanism for user passwords.
 * Does NOT rely on Spring Security — uses Java's built-in MessageDigest.
 *
 * Format stored in DB:  BASE64(salt) + "$" + BASE64(hash)
 */
@Component
public class PasswordUtil {

    private static final String HASH_ALGORITHM = "SHA-256";
    private static final int SALT_LENGTH = 16;
    private static final String DELIMITER = "$";

    /**
     * Hashes a plain-text password with a randomly generated salt.
     *
     * @param rawPassword the plain-text password provided by the user
     * @return a salted hash string safe to store in the database
     */
    public String hashPassword(String rawPassword) {
        try {
            byte[] salt = generateSalt();
            byte[] hash = computeHash(rawPassword, salt);

            String encodedSalt = Base64.getEncoder().encodeToString(salt);
            String encodedHash = Base64.getEncoder().encodeToString(hash);

            return encodedSalt + DELIMITER + encodedHash;

        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 algorithm not available on this platform.", e);
        }
    }

    /**
     * Verifies a plain-text password against a previously hashed value.
     *
     * @param rawPassword    the plain-text password entered by the user
     * @param hashedPassword the stored salted hash from the database
     * @return true if the password matches, false otherwise
     */
    public boolean verifyPassword(String rawPassword, String hashedPassword) {
        try {
            String[] parts = hashedPassword.split("\\" + DELIMITER);
            if (parts.length != 2) {
                return false;
            }

            byte[] salt = Base64.getDecoder().decode(parts[0]);
            byte[] storedHash = Base64.getDecoder().decode(parts[1]);
            byte[] computedHash = computeHash(rawPassword, salt);

            return MessageDigest.isEqual(storedHash, computedHash);

        } catch (NoSuchAlgorithmException | IllegalArgumentException e) {
            return false;
        }
    }

    // ── Private helpers ────────────────────────────────────────────────────

    private byte[] generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[SALT_LENGTH];
        random.nextBytes(salt);
        return salt;
    }

    private byte[] computeHash(String password, byte[] salt) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance(HASH_ALGORITHM);
        digest.update(salt);
        return digest.digest(password.getBytes());
    }
}
