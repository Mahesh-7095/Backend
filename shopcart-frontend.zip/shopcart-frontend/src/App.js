import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

import { AuthProvider }  from './context/AuthContext';
import { CartProvider }  from './context/CartContext';

import LandingPage       from './pages/LandingPage';
import Signup            from './pages/auth/Signup';
import Login             from './pages/auth/Login';
import UserHome          from './pages/user/UserHome';
import UserDashboard     from './pages/user/UserDashboard';
import Cart              from './pages/user/Cart';
import Payment           from './pages/user/Payment';
import AdminDashboard    from './pages/admin/AdminDashboard';
import AdminProfile      from './pages/admin/AdminProfile';
import AdminHome         from './pages/admin/AdminHome';

function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/"               element={<LandingPage />} />
            <Route path="/signup"         element={<Signup />} />
            <Route path="/login"          element={<Login />} />
            <Route path="/user-home"      element={<UserHome />} />
            <Route path="/user-dashboard" element={<UserDashboard />} />
            <Route path="/cart"           element={<Cart />} />
            <Route path="/payment"        element={<Payment />} />
            <Route path="/admin"          element={<AdminDashboard />} />
            <Route path="/AdminDashboard" element={<AdminDashboard />} />
            <Route path="/AdminProfile"   element={<AdminProfile />} />
            <Route path="/admin-home"     element={<AdminHome />} />
          </Routes>
        </BrowserRouter>
      </CartProvider>
    </AuthProvider>
  );
}

export default App;
