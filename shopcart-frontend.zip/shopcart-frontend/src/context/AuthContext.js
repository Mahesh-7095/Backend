import React, { createContext, useContext, useState, useCallback } from 'react';
import api from '../services/api';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    try {
      const saved = localStorage.getItem('shopCartUser');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // ── Login ──────────────────────────────────────────────────────────────────
  const login = useCallback(async (email, password) => {
    const response = await api.post('/auth/login', { email, password });
    const { data } = response.data; // { userId, fullName, email, role, sessionToken }

    localStorage.setItem('sessionToken', data.sessionToken);
    localStorage.setItem('shopCartUser', JSON.stringify(data));
    setUser(data);
    return data;
  }, []);

  // ── Signup ─────────────────────────────────────────────────────────────────
  const signup = useCallback(async (payload) => {
    const response = await api.post('/auth/signup', payload);
    return response.data; // { success, message, data: UserResponse }
  }, []);

  // ── Logout ─────────────────────────────────────────────────────────────────
  const logout = useCallback(async () => {
    try {
      await api.post('/auth/logout');
    } catch (_) {
      // Ignore errors on logout
    } finally {
      localStorage.removeItem('sessionToken');
      localStorage.removeItem('shopCartUser');
      setUser(null);
    }
  }, []);

  return (
    <AuthContext.Provider value={{ user, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
