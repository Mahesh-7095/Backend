import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import logoImg from "../components/logo 1 (1).jpg";

function LandingPage() {
  const navigate = useNavigate();
  const [hoverNav, setHoverNav] = useState(null);
  const [hoverAboutCard, setHoverAboutCard] = useState(null);
  const [hoverServiceCard, setHoverServiceCard] = useState(null);

  return (
    <div style={page}>
      <header style={header}>
        <img src={logoImg} alt="Logo" style={logoStyle} />
        <nav style={navLinks}>
          <a
            href="#home"
            style={{ ...navLink, ...(hoverNav===0?navLinkHover:{}) }}
            onMouseEnter={() => setHoverNav(0)}
            onMouseLeave={() => setHoverNav(null)}
          >Home</a>
          
          <a
            href="#service"
            style={{ ...navLink, ...(hoverNav===2?navLinkHover:{}) }}
            onMouseEnter={() => setHoverNav(2)}
            onMouseLeave={() => setHoverNav(null)}
          >Service</a>
          <a
            href="#contact"
            style={{ ...navLink, ...(hoverNav===3?navLinkHover:{}) }}
            onMouseEnter={() => setHoverNav(3)}
            onMouseLeave={() => setHoverNav(null)}
          >Contact</a>
        </nav>
        <div style={headerActions}>
          <button style={signupBtn} onClick={() => navigate("/signup")}>Sign Up</button>
          <button style={loginBtn} onClick={() => navigate("/login")}>Log In</button>
          <div style={userIcon}>👤</div>
        </div>
      </header>

      <main style={heroSection} id="home">
        <div style={heroContent}>
         
          <h1 style={heroTitle}>Ecommerce Website</h1>
          <p style={heroText}>
         Discover top-quality products at unbeatable prices, crafted to fit every lifestyle. Shop effortlessly with fast delivery, secure checkout, and a seamless browsing experience.
          </p>
          <div style={heroButtons}>
            <button style={outlineBtn} onClick={() => navigate("/signup")}>Try Now</button>
            <button style={solidBtn} onClick={() => navigate("/signup")}>Get it now</button>
          </div>
        </div>

        <div style={heroVisual}>
          <div style={largeCircle} />
          <div style={smallCircle} />
          <div style={ringOne} />
          <div style={ringTwo} />
        </div>
      </main>

     

      

      <section style={serviceSection} id="service">
        <div style={sectionHeader}>
          <div>
            <h2>Our Services</h2>
            <p>Everything you need to launch and grow your online store.</p>
          </div>
        </div>
        <div style={serviceGrid}>
          <div
            style={{ ...serviceCard, ...(hoverServiceCard===0?sectionCardHover:{}) }}
            onMouseEnter={() => setHoverServiceCard(0)}
            onMouseLeave={() => setHoverServiceCard(null)}
          >
            <h3>Store Setup</h3>
            <p>Fast ecommerce onboarding with product uploads, catalog setup, and branding.</p>
          </div>
          <div
            style={{ ...serviceCard, ...(hoverServiceCard===1?sectionCardHover:{}) }}
            onMouseEnter={() => setHoverServiceCard(1)}
            onMouseLeave={() => setHoverServiceCard(null)}
          >
            <h3>Marketing Tools</h3>
            <p>Built-in promotions, email campaigns, and tracking to drive more sales.</p>
          </div>
          <div
            style={{ ...serviceCard, ...(hoverServiceCard===2?sectionCardHover:{}) }}
            onMouseEnter={() => setHoverServiceCard(2)}
            onMouseLeave={() => setHoverServiceCard(null)}
          >
            <h3>Performance</h3>
            <p>Lightweight pages, quick load speed, and mobile-friendly shopping carts.</p>
          </div>
        </div>
      </section>

      <section style={contactSection} id="contact">
        <div style={sectionHeader}>
          <div>
            <h2>Contact Us</h2>
            <p>Get in touch with our support team for sales inquiries and partner assistance.</p>
          </div>
        </div>
        <div style={contactCard}>
          <div style={contactRow}>
            <strong>Email:</strong>
            <span>support@ecomexample.com</span>
          </div>
          <div style={contactRow}>
            <strong>Phone:</strong>
            <span>+1 555 123 9876</span>
          </div>
          <div style={contactRow}>
            <strong>Address:</strong>
            <span>123 Commerce Ave, Suite 500, San Francisco, CA</span>
          </div>
        </div>
      </section>
    </div>
  );
}

export default LandingPage;

const page = {
  minHeight: "100vh",
  background: "linear-gradient(135deg, #0d3f8b 0%, #1e90ff 55%, #90caf9 100%)",
  color: "#fff",
  fontFamily: "Inter, sans-serif",
  padding: "24px"
};

const header = {
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  maxWidth: "1200px",
  margin: "0 auto",
  padding: "8px 0",
  gap: "20px"
};

const logo = {
  fontSize: "20px",
  fontWeight: "800",
  letterSpacing: "1px"
};

const logoStyle = {
  height: "65px",
  width: "65px",
  objectFit: "contain",
  borderRadius: "50%",
  backgroundColor: "white",
  padding: "8px",
  filter: "brightness(1.1)"
};

const navLinks = {
  display: "flex",
  gap: "26px",
  alignItems: "center",
  flexWrap: "wrap"
};

const navLink = {
  display: "inline-block",
  textDecoration: "none",
  color: "rgba(255,255,255,0.9)",
  fontWeight: "500",
  padding: "8px 14px",
  borderRadius: "999px",
  transition: "all 0.25s ease",
  cursor: "pointer"
};

const navLinkHover = {
  color: "#fff",
  background: "linear-gradient(135deg, rgba(0,0,0,0.85), rgba(0,0,0,0.5))",
  boxShadow: "0 10px 20px rgba(0,0,0,0.25)",
  transform: "translateY(-1px)"
};

const headerActions = {
  display: "flex",
  alignItems: "center"
};

const userIcon = {
  fontSize: "24px",
  marginLeft: "16px",
  cursor: "pointer"
};

const signupBtn = {
  background: "#fff",
  color: "#0d3f8b",
  padding: "10px 18px",
  borderRadius: "999px",
  border: "none",
  cursor: "pointer",
  fontWeight: "700",
  marginRight: "12px"
};

const loginBtn = {
  background: "rgba(255,255,255,0.18)",
  border: "1px solid rgba(255,255,255,0.35)",
  color: "#fff",
  padding: "10px 18px",
  borderRadius: "999px",
  cursor: "pointer",
  fontWeight: "600"
};

const heroSection = {
  display: "grid",
  gridTemplateColumns: "1.1fr 0.9fr",
  alignItems: "center",
  gap: "60px",
  maxWidth: "1200px",
  margin: "60px auto 0",
  position: "relative"
};

const heroContent = {
  maxWidth: "560px"
};

const subtitle = {
  display: "inline-block",
  fontSize: "14px",
  letterSpacing: "0.2em",
  textTransform: "uppercase",
  color: "rgba(255,255,255,0.85)",
  marginBottom: "22px"
};

const heroTitle = {
  fontSize: "62px",
  lineHeight: "1.05",
  margin: "0 0 24px",
  maxWidth: "460px"
};

const heroText = {
  fontSize: "18px",
  lineHeight: "1.8",
  color: "rgba(255,255,255,0.9)",
  marginBottom: "32px"
};

const heroButtons = {
  display: "flex",
  gap: "16px",
  flexWrap: "wrap"
};

const outlineBtn = {
  background: "transparent",
  border: "1px solid rgba(255,255,255,0.95)",
  color: "#fff",
  padding: "14px 26px",
  borderRadius: "30px",
  cursor: "pointer",
  fontWeight: "600"
};

const solidBtn = {
  background: "#fff",
  color: "#0d3f8b",
  padding: "14px 26px",
  borderRadius: "30px",
  border: "none",
  cursor: "pointer",
  fontWeight: "700"
};

const heroVisual = {
  position: "relative",
  minHeight: "520px"
};

const largeCircle = {
  position: "absolute",
  right: "-40px",
  top: "40px",
  width: "260px",
  height: "260px",
  borderRadius: "50%",
  background: "rgba(255,255,255,0.14)"
};

const smallCircle = {
  position: "absolute",
  right: "60px",
  top: "220px",
  width: "120px",
  height: "120px",
  borderRadius: "50%",
  background: "rgba(255,255,255,0.22)"
};

const ringOne = {
  position: "absolute",
  right: "-20px",
  bottom: "100px",
  width: "140px",
  height: "140px",
  borderRadius: "50%",
  border: "3px solid rgba(255,255,255,0.35)"
};

const ringTwo = {
  position: "absolute",
  right: "120px",
  bottom: "20px",
  width: "80px",
  height: "80px",
  borderRadius: "50%",
  border: "2px solid rgba(255,255,255,0.5)"
};

const featureSection = {
  maxWidth: "1200px",
  margin: "60px auto 0",
  padding: "40px 0",
  color: "#fff"
};

const featureGrid = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
  gap: "20px"
};

const featureCard = {
  border: "1px solid rgba(255,255,255,0.22)",
  borderRadius: "24px",
  padding: "28px",
  minHeight: "180px",
  transition: "transform 0.25s ease, box-shadow 0.25s ease",
  cursor: "pointer"
};

const dotGrid = {
  width: "120px",
  height: "120px",
  backgroundImage: "radial-gradient(rgba(255,255,255,0.3) 1px, transparent 1px)",
  backgroundSize: "12px 12px"
};

const aboutSection = {
  maxWidth: "1200px",
  margin: "80px auto 0",
  padding: "40px 0",
  color: "#fff"
};

const sectionHeader = {
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  gap: "24px",
  flexWrap: "wrap",
  marginBottom: "28px"
};

const aboutCards = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
  gap: "20px"
};

const aboutCard = {
  background: "rgba(255,255,255,0.12)",
  border: "1px solid rgba(255,255,255,0.22)",
  borderRadius: "24px",
  padding: "24px",
  minHeight: "170px",
  transition: "transform 0.25s ease, box-shadow 0.25s ease",
  cursor: "pointer"
};

const sectionCardHover = {
  transform: "translateY(-8px)",
  boxShadow: "0 24px 50px rgba(0,0,0,0.18)",
  borderColor: "rgba(255,255,255,0.35)"
};

const serviceSection = {
  maxWidth: "1200px",
  margin: "80px auto 0",
  padding: "40px 0",
  color: "#fff"
};

const serviceGrid = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
  gap: "20px"
};

const serviceCard = {
  background: "rgba(255,255,255,0.14)",
  border: "1px solid rgba(255,255,255,0.24)",
  borderRadius: "24px",
  padding: "28px",
  minHeight: "180px",
  transition: "transform 0.25s ease, box-shadow 0.25s ease",
  cursor: "pointer"
};

const contactSection = {
  maxWidth: "1200px",
  margin: "80px auto 60px",
  padding: "40px 0",
  color: "#fff"
};

const contactCard = {
  background: "rgba(255,255,255,0.14)",
  border: "1px solid rgba(255,255,255,0.2)",
  borderRadius: "24px",
  padding: "28px",
  display: "grid",
  gap: "16px"
};

const contactRow = {
  display: "flex",
  justifyContent: "space-between",
  flexWrap: "wrap",
  gap: "10px",
  color: "rgba(255,255,255,0.95)",
  fontSize: "16px"
};
