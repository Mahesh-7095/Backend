import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { adminTheme } from '../../theme';
import api from '../../services/api';

function AdminDashboard() {
  const navigate = useNavigate();

  const [categories, setCategories]           = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [loading, setLoading]                 = useState(true);

  const [showProductForm, setShowProductForm]   = useState(false);
  const [showCategoryForm, setShowCategoryForm] = useState(false);
  const [editingProductId, setEditingProductId] = useState(null);
  const [selectedProductIndex, setSelectedProductIndex] = useState(null);

  const [newProduct, setNewProduct] = useState({ name: '', imageUrl: '', quantity: '', price: '' });
  const [categoryForm, setCategoryForm] = useState({ name: '', discount: '' });

  const [hoverCategory, setHoverCategory] = useState(null);
  const [hoverProduct, setHoverProduct]   = useState(null);
  const [hoverStat, setHoverStat]         = useState(null);

  /* ── Load categories from backend ─────────────────────────────────────── */
  const loadCategories = useCallback(async () => {
    try {
      const res = await api.get('/categories');
      const list = res.data.data || [];
      setCategories(list);
      if (list.length > 0 && !selectedCategory) {
        // Load first category with its products
        loadCategoryWithProducts(list[0].id, list);
      }
    } catch (err) {
      console.error('Failed to load categories', err);
    } finally {
      setLoading(false);
    }
  }, []); // eslint-disable-line

  const loadCategoryWithProducts = async (id, cats) => {
    try {
      const res = await api.get(`/categories/${id}`);
      const cat = res.data.data;
      setSelectedCategory(cat);
      // Sync into categories list
      setCategories((prev) =>
        prev.map ? prev.map((c) => (c.id === id ? { ...c, products: cat.products } : c))
          : (cats || []).map((c) => (c.id === id ? { ...c, products: cat.products } : c))
      );
    } catch { }
  };

  useEffect(() => { loadCategories(); }, [loadCategories]);

  const handleSelectCategory = (cat) => {
    setSelectedProductIndex(null);
    loadCategoryWithProducts(cat.id, categories);
  };

  const getTotalQuantity = (products = []) =>
    products.reduce((sum, p) => sum + Number(p.quantity || 0), 0);

  /* ── Product CRUD ────────────────────────────────────────────────────── */
  const handleSaveProduct = async (e) => {
    e.preventDefault();
    if (!selectedCategory) return;

    const payload = {
      name:       newProduct.name,
      imageUrl:   newProduct.imageUrl,
      price:      Number(newProduct.price),
      quantity:   Number(newProduct.quantity),
      discount:   newProduct.discount || '',
      categoryId: selectedCategory.id,
    };

    try {
      if (editingProductId) {
        await api.put(`/products/${editingProductId}`, payload);
      } else {
        await api.post('/products', payload);
      }
      await loadCategoryWithProducts(selectedCategory.id, categories);
      setNewProduct({ name: '', imageUrl: '', quantity: '', price: '', discount: '' });
      setEditingProductId(null);
      setSelectedProductIndex(null);
      setShowProductForm(false);
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to save product.');
    }
  };

  const handleUpdateClick = () => {
    const p = selectedCategory.products[selectedProductIndex];
    setNewProduct({ name: p.name, imageUrl: p.image || p.imageUrl || '', quantity: p.quantity, price: p.price, discount: p.discount || '' });
    setEditingProductId(p.id);
    setShowProductForm(true);
  };

  const handleDeleteProduct = async () => {
    const p = selectedCategory.products[selectedProductIndex];
    if (!window.confirm(`Delete "${p.name}"?`)) return;
    try {
      await api.delete(`/products/${p.id}`);
      await loadCategoryWithProducts(selectedCategory.id, categories);
      setSelectedProductIndex(null);
    } catch (err) {
      alert(err.response?.data?.message || 'Delete failed.');
    }
  };

  /* ── Category CRUD ───────────────────────────────────────────────────── */
  const handleAddCategory = async () => {
    try {
      await api.post('/categories', { name: categoryForm.name, discount: categoryForm.discount + '%' });
      await loadCategories();
      setCategoryForm({ name: '', discount: '' });
      setShowCategoryForm(false);
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to add category.');
    }
  };

  const handleUpdateCategoryDiscount = async () => {
    if (!selectedCategory) return;
    try {
      await api.patch(`/categories/${selectedCategory.id}/discount`, { discount: categoryForm.discount + '%' });
      await loadCategories();
      setCategoryForm({ name: '', discount: '' });
      setShowCategoryForm(false);
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to update discount.');
    }
  };

  const handleDeleteCategory = async () => {
    if (!selectedCategory) return;
    if (!window.confirm(`Delete category "${selectedCategory.name}" and all its products?`)) return;
    try {
      await api.delete(`/categories/${selectedCategory.id}`);
      setSelectedCategory(null);
      await loadCategories();
      setShowCategoryForm(false);
    } catch (err) {
      alert(err.response?.data?.message || 'Delete failed.');
    }
  };

  if (loading) {
    return (
      <div style={{ ...dashboard, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <h2 style={{ color: '#333' }}>Loading Admin Dashboard...</h2>
      </div>
    );
  }

  return (
    <div style={dashboard}>
      <h1 style={title}>Admin Dashboard</h1>
      <button style={profileBtn} onClick={() => navigate('/AdminProfile')} title="Admin Profile">👤</button>

      {/* Category Cards */}
      <div style={categoryRow}>
        {categories.map((cat, i) => (
          <div
            key={cat.id}
            onClick={() => handleSelectCategory(cat)}
            onMouseEnter={() => setHoverCategory(i)}
            onMouseLeave={() => setHoverCategory(null)}
            style={{ ...categoryCard, ...(hoverCategory === i ? hoverStyle : {}), ...(selectedCategory?.id === cat.id ? activeCategoryStyle : {}) }}
          >
            <h3>{cat.name}</h3>
            <p>{cat.discount}</p>
          </div>
        ))}
        <button style={plusBtn} onClick={() => setShowCategoryForm(true)}>Add Category</button>
      </div>

      {/* Stats */}
      {selectedCategory && (
        <div style={statGrid}>
          {[
            { label: 'Total Products', value: getTotalQuantity(selectedCategory.products) },
            { label: 'Products Sold',  value: selectedCategory.sold },
            { label: 'Remaining',      value: getTotalQuantity(selectedCategory.products) - (selectedCategory.sold || 0) },
            { label: 'Discount',       value: selectedCategory.discount },
          ].map((stat, i) => (
            <div
              key={i}
              style={{ ...statCard, ...(hoverStat === i ? hoverStyle : {}) }}
              onMouseEnter={() => setHoverStat(i)}
              onMouseLeave={() => setHoverStat(null)}
            >
              <h4>{stat.label}</h4>
              <h2>{stat.value ?? 0}</h2>
            </div>
          ))}
        </div>
      )}

      {/* Products Table */}
      {selectedCategory && (
        <div>
          <div style={productHeader}>
            <button style={smallPlus} onClick={() => { setEditingProductId(null); setSelectedProductIndex(null); setNewProduct({ name: '', imageUrl: '', quantity: '', price: '', discount: '' }); setShowProductForm(true); }}>+</button>
            <h3>Products in {selectedCategory.name}</h3>
            <div style={{ marginLeft: 'auto', display: 'flex', gap: '10px' }}>
              <button style={{ ...updateBtn, opacity: selectedProductIndex === null ? 0.5 : 1 }} disabled={selectedProductIndex === null} onClick={handleUpdateClick}>✏️ Update</button>
              <button style={{ ...deleteBtn, opacity: selectedProductIndex === null ? 0.5 : 1 }} disabled={selectedProductIndex === null} onClick={handleDeleteProduct}>🗑️ Delete</button>
            </div>
          </div>

          {(!selectedCategory.products || selectedCategory.products.length === 0) ? (
            <p style={{ color: '#888', textAlign: 'center', padding: '30px' }}>No products yet. Click + to add one.</p>
          ) : (
            <div style={productGrid}>
              {selectedCategory.products.map((p, i) => (
                <div
                  key={p.id}
                  onClick={() => setSelectedProductIndex(i)}
                  onMouseEnter={() => setHoverProduct(i)}
                  onMouseLeave={() => setHoverProduct(null)}
                  style={{
                    ...productCard,
                    ...(hoverProduct === i ? productHoverStyle : {}),
                    ...(selectedProductIndex === i ? selectedProductStyle : {}),
                  }}
                >
                  <img src={p.image || p.imageUrl} alt={p.name} style={productImage} onError={(e) => { e.target.src = 'https://via.placeholder.com/150'; }} />
                  <h4>{p.name}</h4>
                  <div style={{ ...productDetails, ...(hoverProduct === i ? productDetailsHover : {}) }}>
                    <span style={{ ...detailText, ...(hoverProduct === i ? detailTextHover : {}) }}>Qty: {p.quantity}</span>
                    <span style={{ ...detailText, ...(hoverProduct === i ? detailTextHover : {}) }}>₹{Number(p.price).toLocaleString('en-IN')}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Product Form Modal */}
      {showProductForm && (
        <div style={popup}>
          <div style={popupBox}>
            <button style={closeBtn} onClick={() => setShowProductForm(false)}>✖</button>
            <h3>{editingProductId ? 'Update Product' : 'Add Product'}</h3>
            <form onSubmit={handleSaveProduct}>
              <input style={input} placeholder="Product Name" value={newProduct.name} onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })} required />
              <input style={input} placeholder="Image URL" value={newProduct.imageUrl} onChange={(e) => setNewProduct({ ...newProduct, imageUrl: e.target.value })} />
              <input style={input} placeholder="Quantity" type="number" min="0" value={newProduct.quantity} onChange={(e) => setNewProduct({ ...newProduct, quantity: e.target.value })} required />
              <input style={input} placeholder="Price (₹)" type="number" min="0.01" step="0.01" value={newProduct.price} onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })} required />
              <input style={input} placeholder="Discount (e.g. 15%)" value={newProduct.discount || ''} onChange={(e) => setNewProduct({ ...newProduct, discount: e.target.value })} />
              <button type="submit" style={submitBtn}>{editingProductId ? 'Update' : 'Save'}</button>
            </form>
          </div>
        </div>
      )}

      {/* Category Form Modal */}
      {showCategoryForm && (
        <div style={popup}>
          <div style={popupBox}>
            <button style={closeBtn} onClick={() => setShowCategoryForm(false)}>✖</button>
            <h3>Category Settings</h3>
            <input style={input} placeholder="Category Name" value={categoryForm.name} onChange={(e) => setCategoryForm({ ...categoryForm, name: e.target.value })} />
            <input style={input} placeholder="Discount %" value={categoryForm.discount} onChange={(e) => setCategoryForm({ ...categoryForm, discount: e.target.value })} />
            <button style={categoryAddBtn} onClick={handleAddCategory}>Add Category</button>
            <button style={categoryUpdateBtn} onClick={handleUpdateCategoryDiscount}>Update Discount</button>
            <button style={categoryDeleteBtn} onClick={handleDeleteCategory}>Delete Category</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default AdminDashboard;

/* ======= Styles ======= */
const dashboard         = { padding: '20px', background: adminTheme.dashboardBg, minHeight: '100vh', position: 'relative' };
const title             = { textAlign: 'center' };
const categoryRow       = { display: 'flex', flexWrap: 'wrap', gap: '20px', justifyContent: 'center', alignItems: 'flex-start', margin: '30px 0' };
const categoryCard      = { background: 'white', padding: '20px', width: '160px', height: '90px', borderRadius: '18px', textAlign: 'center', cursor: 'pointer', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', boxShadow: '0 3px 10px rgba(0,0,0,0.15)', transition: 'all 0.25s' };
const activeCategoryStyle = { border: '3px solid #29b6f6' };
const plusBtn           = { width: '120px', height: '55px', borderRadius: '14px', fontSize: '14px', background: '#29b6f6', color: 'white', border: 'none', cursor: 'pointer', fontWeight: '700', boxShadow: '0 3px 10px rgba(0,0,0,0.14)' };
const statGrid          = { display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '20px', marginBottom: '30px' };
const statCard          = { background: 'white', padding: '20px', borderRadius: '12px', textAlign: 'center', boxShadow: '0 3px 10px rgba(0,0,0,0.15)', cursor: 'pointer' };
const productHeader     = { display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap', marginBottom: '20px' };
const smallPlus         = { width: '40px', height: '40px', borderRadius: '50%', background: '#29b6f6', border: 'none', cursor: 'pointer', fontSize: '20px', color: 'white', fontWeight: 'bold' };
const productGrid       = { display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(200px,1fr))', gap: '20px' };
const productCard       = { background: 'white', padding: '15px', borderRadius: '15px', textAlign: 'center', cursor: 'pointer', boxShadow: '0 3px 10px rgba(0,0,0,0.15)', transition: 'all 0.25s' };
const selectedProductStyle = { border: '3px solid #29b6f6' };
const productImage      = { width: '100%', height: '120px', objectFit: 'cover', borderRadius: '10px' };
const popup             = { position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.4)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 1000 };
const popupBox          = { background: 'white', padding: '25px', width: '340px', borderRadius: '15px', position: 'relative' };
const closeBtn          = { position: 'absolute', top: '10px', right: '10px', border: 'none', background: 'red', color: 'white', cursor: 'pointer', borderRadius: '4px', padding: '4px 8px' };
const profileBtn        = { position: 'absolute', top: '20px', right: '20px', width: '44px', height: '44px', borderRadius: '50%', border: 'none', background: adminTheme.primary, color: 'white', cursor: 'pointer', fontSize: '18px', boxShadow: '0 3px 10px rgba(0,0,0,0.2)' };
const input             = { width: '100%', padding: '10px', marginBottom: '10px', borderRadius: '6px', border: '1px solid #ccc', boxSizing: 'border-box' };
const submitBtn         = { width: '100%', padding: '10px', background: '#29b6f6', border: 'none', cursor: 'pointer', borderRadius: '6px', color: 'white', fontWeight: 'bold' };
const categoryAddBtn    = { width: '100%', padding: '12px', background: '#dcedc8', color: '#33691e', border: 'none', borderRadius: '30px', marginTop: '10px', cursor: 'pointer', fontWeight: '600' };
const categoryUpdateBtn = { width: '100%', padding: '12px', background: 'rgba(13,71,161,0.12)', color: '#0d47a1', border: '1px solid rgba(13,71,161,0.25)', borderRadius: '28px', marginTop: '10px', cursor: 'pointer', fontWeight: '600' };
const categoryDeleteBtn = { width: '100%', padding: '12px', background: 'rgba(183,28,28,0.12)', color: '#b71c1c', border: '1px solid rgba(183,28,28,0.25)', borderRadius: '28px', marginTop: '10px', cursor: 'pointer', fontWeight: '600' };
const updateBtn         = { padding: '10px 18px', background: 'rgba(76,175,80,0.12)', color: '#1b5e20', border: '1px solid rgba(76,175,80,0.25)', borderRadius: '24px', cursor: 'pointer' };
const deleteBtn         = { padding: '10px 18px', background: 'rgba(229,57,53,0.12)', color: '#b71c1c', border: '1px solid rgba(229,57,53,0.25)', borderRadius: '24px', cursor: 'pointer' };
const hoverStyle        = { transform: 'scale(1.05)', background: '#000', color: '#fff', transition: '0.25s' };
const productHoverStyle = { transform: 'scale(1.05)', background: '#fffde7', transition: '0.25s', boxShadow: '0 6px 22px rgba(0,0,0,0.18)' };
const productDetails    = { display: 'flex', justifyContent: 'space-between', padding: '12px 14px', marginTop: '14px', borderRadius: '16px', background: '#000' };
const productDetailsHover = { background: '#fff59d' };
const detailText        = { fontSize: '14px', fontWeight: '700', color: '#fff' };
const detailTextHover   = { color: '#000' };
