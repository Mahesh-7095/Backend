import React from "react";
import { useNavigate } from "react-router-dom";

function AdminHome() {
  const navigate = useNavigate();

  return (
    <div style={styles.container}>
      <h1>Welcome to Admin Home</h1>
      <p>This is the admin home page</p>
      <button style={styles.btn} onClick={() => navigate("/admin")}>
        Go to Dashboard
      </button>
    </div>
  );
}

const styles = {
  container: {
    padding: "40px",
    textAlign: "center",
    minHeight: "100vh",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
    color: "white"
  },
  btn: {
    marginTop: "20px",
    padding: "12px 24px",
    background: "white",
    color: "#667eea",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    fontWeight: "600",
    fontSize: "16px"
  }
};

export default AdminHome;
