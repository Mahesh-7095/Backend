import React from "react";
import { useNavigate } from "react-router-dom";
import { adminTheme } from "../../theme";

function AdminProfile() {
  const navigate = useNavigate();
  const admin = {
    name: "Admin User",
    email: "admin@example.com",
    role: "Administrator",
    joined: "January 2024",
    lastLogin: "March 31, 2026, 11:45 AM"
  };

  return (
    <div style={page}>
      <div style={card}>
        <button style={backBtn} onClick={() => navigate("/AdminDashboard")}>Back to Dashboard</button>
        <div style={avatar}>👤</div>
        <h2>Admin Profile</h2>
        <div style={infoRow}>
          <span>Name</span>
          <strong>{admin.name}</strong>
        </div>
        <div style={infoRow}>
          <span>Email</span>
          <strong>{admin.email}</strong>
        </div>
        <div style={infoRow}>
          <span>Role</span>
          <strong>{admin.role}</strong>
        </div>
        <div style={infoRow}>
          <span>Member Since</span>
          <strong>{admin.joined}</strong>
        </div>
        <div style={infoRow}>
          <span>Last Login</span>
          <strong>{admin.lastLogin}</strong>
        </div>
      </div>
    </div>
  );
}

export default AdminProfile;

const page = {
  minHeight: "100vh",
  padding: "30px",
  background: adminTheme.dashboardBg,
  display: "flex",
  justifyContent: "center",
  alignItems: "center"
};

const card = {
  width: "100%",
  maxWidth: "420px",
  background: adminTheme.cardBg,
  padding: "30px",
  borderRadius: "20px",
  boxShadow: "0 10px 30px rgba(0,0,0,0.12)",
  textAlign: "center",
  position: "relative"
};

const backBtn = {
  position: "absolute",
  top: "18px",
  right: "18px",
  border: "none",
  background: adminTheme.primary,
  color: "white",
  padding: "10px 14px",
  borderRadius: "12px",
  cursor: "pointer"
};

const avatar = {
  fontSize: "72px",
  marginBottom: "20px"
};

const infoRow = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  padding: "12px 0",
  borderBottom: "1px solid #e0e0e0",
  fontSize: "16px"
};
