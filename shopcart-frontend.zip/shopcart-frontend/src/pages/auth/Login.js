import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [form, setForm]       = useState({ email: '', password: '' });
  const [error, setError]     = useState('');
  const [loading, setLoading] = useState(false);
  const [hover, setHover]     = useState(false);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const data = await login(form.email, form.password);

      if (data.role === 'ADMIN') {
        navigate('/admin');
      } else {
        navigate('/user-home');
      }
    } catch (err) {
      const msg =
        err.response?.data?.message || 'Login failed. Please check your credentials.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        <h2 style={titleStyle}>Login</h2>

        {error && <div style={errorBox}>{error}</div>}

        <form onSubmit={handleLogin}>
          <input
            type="email"
            name="email"
            placeholder="Email"
            value={form.email}
            onChange={handleChange}
            style={inputStyle}
            required
          />
          <input
            type="password"
            name="password"
            placeholder="Password"
            value={form.password}
            onChange={handleChange}
            style={inputStyle}
            required
          />
          <button
            type="submit"
            disabled={loading}
            onMouseEnter={() => setHover(true)}
            onMouseLeave={() => setHover(false)}
            style={{ ...buttonStyle, ...(hover ? buttonHover : {}), opacity: loading ? 0.7 : 1 }}
          >
            {loading ? 'Logging in...' : 'Login'}
          </button>
        </form>

        <p style={loginText}>
          Don't have an account? <Link to="/signup">Signup</Link>
        </p>
      </div>
    </div>
  );
}

/* ---------- Styles ---------- */
const pageStyle = {
  height: '100vh', display: 'flex', justifyContent: 'center',
  alignItems: 'center', background: 'linear-gradient(135deg,#001f4d,#4fc3f7)', fontFamily: 'Arial',
};
const cardStyle = {
  width: '380px', padding: '35px', borderRadius: '12px',
  background: 'white', boxShadow: '0 10px 25px rgba(0,0,0,0.3)',
};
const titleStyle  = { textAlign: 'center', marginBottom: '25px', color: '#001f4d' };
const inputStyle  = {
  width: '100%', padding: '12px', marginBottom: '15px', borderRadius: '6px',
  border: '1px solid #ccc', fontSize: '14px', outline: 'none', boxSizing: 'border-box',
};
const buttonStyle = {
  width: '100%', padding: '12px', background: 'linear-gradient(90deg,#001f4d,#4fc3f7)',
  color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer',
  fontSize: '16px', transition: '0.3s',
};
const buttonHover  = { background: 'linear-gradient(90deg,#4fc3f7,#001f4d)', transform: 'scale(1.05)', boxShadow: '0 5px 15px rgba(0,0,0,0.3)' };
const loginText    = { textAlign: 'center', marginTop: '15px' };
const errorBox     = { background: '#ffe0e0', color: '#c00', padding: '10px 14px', borderRadius: '6px', marginBottom: '15px', fontSize: '14px' };

export default Login;
