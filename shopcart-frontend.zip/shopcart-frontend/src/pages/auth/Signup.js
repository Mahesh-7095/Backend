import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const Signup = () => {
  const navigate = useNavigate();
  const { signup } = useAuth();

  const [user, setUser] = useState({
    fullName: '', email: '', phone: '', password: '', confirmPassword: '',
  });
  const [error, setError]     = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) =>
    setUser({ ...user, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (user.password !== user.confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    setLoading(true);
    try {
      const res = await signup({
        fullName: user.fullName,
        email:    user.email,
        phone:    user.phone,
        password: user.password,
      });

      if (res.success) {
        alert(res.message || 'Account created! Please login.');
        navigate('/login');
      }
    } catch (err) {
      const msg =
        err.response?.data?.message || 'Signup failed. Please try again.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        <h2 style={titleStyle}>User Signup</h2>

        {error && <div style={errorBox}>{error}</div>}

        <form onSubmit={handleSubmit}>
          {[
            { name: 'fullName',        type: 'text',     placeholder: 'Full Name' },
            { name: 'email',           type: 'email',    placeholder: 'Email' },
            { name: 'phone',           type: 'tel',      placeholder: 'Phone Number (10 digits)' },
            { name: 'password',        type: 'password', placeholder: 'Password' },
            { name: 'confirmPassword', type: 'password', placeholder: 'Confirm Password' },
          ].map((field) => (
            <input
              key={field.name}
              type={field.type}
              name={field.name}
              placeholder={field.placeholder}
              value={user[field.name]}
              onChange={handleChange}
              style={inputStyle}
              required
            />
          ))}

          <button type="submit" disabled={loading} style={{ ...buttonStyle, opacity: loading ? 0.7 : 1 }}>
            {loading ? 'Registering...' : 'Register'}
          </button>
        </form>

        <p style={loginText}>
          Already have an account? <Link to="/login">Login</Link>
        </p>
      </div>
    </div>
  );
};

/* ======= Styles ======= */
const pageStyle  = { height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center', background: 'linear-gradient(135deg, #001f4d, #4fc3f7)' };
const cardStyle  = { width: '400px', padding: '35px', borderRadius: '12px', background: '#ffffff', boxShadow: '0 10px 25px rgba(0,0,0,0.3)' };
const titleStyle = { textAlign: 'center', marginBottom: '20px', color: '#001f4d' };
const inputStyle = { width: '100%', padding: '12px', marginBottom: '15px', borderRadius: '6px', border: '1px solid #ccc', boxSizing: 'border-box', fontSize: '14px', outline: 'none' };
const buttonStyle = { width: '100%', padding: '12px', background: 'linear-gradient(90deg, #001f4d, #4fc3f7)', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold', fontSize: '15px' };
const loginText  = { textAlign: 'center', marginTop: '15px' };
const errorBox   = { background: '#ffe0e0', color: '#c00', padding: '10px 14px', borderRadius: '6px', marginBottom: '15px', fontSize: '14px' };

export default Signup;
