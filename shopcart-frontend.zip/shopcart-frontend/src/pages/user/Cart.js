import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../../context/CartContext';

const Cart = () => {
  const navigate = useNavigate();
  const { cart, removeFromCart, updateQuantity, getTotal } = useCart();

  return (
    <div style={pageStyle}>
      <header style={headerStyle}>
        <div style={headerContent}>
          <span style={backBtn} onClick={() => navigate('/user-home')}>← Back</span>
          <h2 style={headerTitle}>My Cart</h2>
          <span style={{ width: '60px' }} />
        </div>
      </header>

      <div style={cartContainer}>
        {cart.length === 0 ? (
          <div style={emptyCartContainer}>
            <p style={emptyCart}>Your cart is empty.</p>
            <button style={continueShopping} onClick={() => navigate('/user-home')}>Continue Shopping</button>
          </div>
        ) : (
          <div style={content}>
            {/* Cart Items */}
            <div style={itemsSection}>
              <h3 style={itemsTitle}>Items in Cart</h3>
              {cart.map((item) => (
                <div key={item.id} style={itemCard}>
                  <img src={item.image} alt={item.name} style={itemImage} />
                  <div style={itemInfo}>
                    <h4 style={itemName}>{item.name}</h4>
                    <p style={itemPrice}>₹{Number(item.price).toLocaleString('en-IN')}</p>
                  </div>
                  <div style={itemActions}>
                    <div style={quantityControls}>
                      <button onClick={() => updateQuantity(item.id, item.quantity - 1)} style={qtyBtn}>−</button>
                      <span style={qtyLabel}>{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.id, item.quantity + 1)} style={qtyBtn}>+</button>
                    </div>
                    <button onClick={() => removeFromCart(item.id)} style={removeBtn}>Remove</button>
                  </div>
                </div>
              ))}
            </div>

            {/* Order Summary */}
            <div style={summaryPanel}>
              <h3 style={summaryTitle}>Order Summary</h3>
              <div style={summaryDivider} />
              <div style={summaryRow}>
                <span>Total Items</span>
                <span>{cart.reduce((c, i) => c + i.quantity, 0)}</span>
              </div>
              <div style={summaryRow}>
                <span style={totalLabelStyle}>Total Price</span>
                <span style={totalPriceStyle}>₹{getTotal().toLocaleString('en-IN')}</span>
              </div>
              <button style={orderBtn} onClick={() => navigate('/payment')}>Order Now</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

/* ======= Styles ======= */
const pageStyle           = { fontFamily: "'Poppins', sans-serif", background: 'linear-gradient(135deg, #001f4d, #4fc3f7)', minHeight: '100vh', paddingBottom: '50px' };
const headerStyle         = { backgroundColor: 'white', padding: '20px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', marginBottom: '30px' };
const headerContent       = { display: 'flex', justifyContent: 'space-between', alignItems: 'center', maxWidth: '1200px', margin: '0 auto' };
const backBtn             = { fontSize: '18px', cursor: 'pointer', color: '#001f4d', fontWeight: '500' };
const headerTitle         = { fontSize: '24px', fontWeight: 'bold', color: '#001f4d', margin: 0 };
const cartContainer       = { maxWidth: '1200px', margin: '0 auto', padding: '0 20px' };
const content             = { display: 'grid', gridTemplateColumns: '1fr 350px', gap: '30px' };
const itemsSection        = { backgroundColor: 'white', borderRadius: '15px', padding: '30px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)' };
const itemsTitle          = { fontSize: '22px', fontWeight: 'bold', color: '#001f4d', marginTop: 0, marginBottom: '20px' };
const itemCard            = { display: 'flex', alignItems: 'center', gap: '20px', padding: '15px', backgroundColor: '#f9f9f9', borderRadius: '12px', marginBottom: '15px', border: '1px solid #f0f0f0' };
const itemImage           = { width: '80px', height: '80px', objectFit: 'cover', borderRadius: '10px' };
const itemInfo            = { flex: 1 };
const itemName            = { fontSize: '16px', fontWeight: 'bold', color: '#333', margin: '0 0 5px' };
const itemPrice           = { fontSize: '16px', fontWeight: 'bold', color: '#001f4d', margin: 0 };
const itemActions         = { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '10px' };
const quantityControls    = { display: 'flex', alignItems: 'center', gap: '8px', backgroundColor: 'white', borderRadius: '8px', padding: '5px' };
const qtyBtn              = { width: '28px', height: '28px', borderRadius: '50%', border: 'none', backgroundColor: '#001f4d', color: 'white', cursor: 'pointer', fontSize: '16px' };
const qtyLabel            = { fontSize: '14px', color: '#333', minWidth: '30px', textAlign: 'center', fontWeight: '500' };
const removeBtn           = { backgroundColor: '#ff4444', color: 'white', border: 'none', padding: '8px 16px', borderRadius: '20px', fontSize: '12px', fontWeight: 'bold', cursor: 'pointer' };
const summaryPanel        = { backgroundColor: 'white', borderRadius: '15px', padding: '25px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)', height: 'fit-content', position: 'sticky', top: '20px' };
const summaryTitle        = { fontSize: '18px', fontWeight: 'bold', color: '#001f4d', margin: '0 0 15px' };
const summaryDivider      = { height: '1px', backgroundColor: '#e0e0e0', marginBottom: '15px' };
const summaryRow          = { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px', fontSize: '15px', color: '#333' };
const totalLabelStyle     = { fontWeight: 'bold', color: '#001f4d' };
const totalPriceStyle     = { fontWeight: 'bold', color: '#001f4d', fontSize: '18px' };
const orderBtn            = { width: '100%', padding: '15px', background: 'linear-gradient(90deg, #001f4d, #4fc3f7)', color: 'white', border: 'none', borderRadius: '25px', fontSize: '16px', fontWeight: 'bold', cursor: 'pointer', marginTop: '15px' };
const emptyCartContainer  = { backgroundColor: 'white', borderRadius: '15px', padding: '60px 30px', textAlign: 'center', boxShadow: '0 4px 8px rgba(0,0,0,0.1)' };
const emptyCart           = { fontSize: '18px', color: '#666', marginBottom: '20px' };
const continueShopping    = { background: 'linear-gradient(90deg, #001f4d, #4fc3f7)', color: 'white', border: 'none', padding: '12px 30px', borderRadius: '25px', fontSize: '16px', fontWeight: 'bold', cursor: 'pointer' };

export default Cart;
