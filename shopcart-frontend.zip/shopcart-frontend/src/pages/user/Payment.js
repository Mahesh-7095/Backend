import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import api from '../../services/api';

const Payment = () => {
  const navigate = useNavigate();
  const { cart, getTotal, clearCart } = useCart();
  const { user } = useAuth();

  const [paymentDetails, setPaymentDetails] = useState({ cardNumber: '', expiry: '', cvv: '', name: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState('');

  const handleChange = (e) =>
    setPaymentDetails({ ...paymentDetails, [e.target.name]: e.target.value });

  const handlePayment = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Build order payload for backend
      const orderPayload = {
        userId:        user?.userId || 1,
        items:         cart.map((item) => ({
          productId: item.id,
          name:      item.name,
          image:     item.image,
          price:     Number(item.price),
          quantity:  item.quantity,
        })),
        totalAmount:   getTotal(),
        paymentMethod: 'Credit Card',
      };

      await api.post('/orders', orderPayload);

      clearCart();
      alert('Payment successful! Your order has been placed.');
      navigate('/user-dashboard');
    } catch (err) {
      setError(err.response?.data?.message || 'Payment failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (cart.length === 0) {
    return (
      <div style={pageStyle}>
        <header style={headerStyle}>
          <div style={headerContent}>
            <span style={backBtn} onClick={() => navigate('/cart')}>← Back</span>
            <h2 style={headerTitle}>Payment</h2>
            <span style={{ width: '60px' }} />
          </div>
        </header>
        <div style={paymentContainer}>
          <div style={summarySection}>
            <p style={{ textAlign: 'center', fontSize: '18px', color: '#666' }}>
              No items in cart. <span style={{ color: '#001f4d', cursor: 'pointer' }} onClick={() => navigate('/user-home')}>Go shopping</span>
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={pageStyle}>
      <header style={headerStyle}>
        <div style={headerContent}>
          <span style={backBtn} onClick={() => navigate('/cart')}>← Back</span>
          <h2 style={headerTitle}>Payment</h2>
          <span style={{ width: '60px' }} />
        </div>
      </header>

      <div style={paymentContainer}>
        {error && <div style={errorBox}>{error}</div>}

        <div style={content}>
          {/* Order Summary */}
          <div style={summarySection}>
            <h3 style={summaryTitle}>Order Summary</h3>
            <div style={itemsList}>
              {cart.map((item) => (
                <div key={item.id} style={summaryItem}>
                  <div>
                    <p style={itemNameStyle}>{item.name}</p>
                    <p style={itemQuantityStyle}>Qty: {item.quantity}</p>
                  </div>
                  <p style={itemTotalStyle}>₹{(Number(item.price) * item.quantity).toLocaleString('en-IN')}</p>
                </div>
              ))}
            </div>
            <div style={summaryDivider} />
            <div style={totalRow}>
              <span style={totalLabel}>Total Amount</span>
              <span style={totalAmount}>₹{getTotal().toLocaleString('en-IN')}</span>
            </div>
          </div>

          {/* Payment Form */}
          <div style={formSection}>
            <h3 style={formTitle}>Payment Details</h3>
            <form onSubmit={handlePayment} style={form}>
              <div style={formRow}>
                <div style={formGroup}>
                  <label style={labelStyle}>Cardholder Name</label>
                  <input type="text" name="name" placeholder="Enter name" value={paymentDetails.name} onChange={handleChange} style={inputStyle} required />
                </div>
              </div>
              <div style={formRow}>
                <div style={formGroup}>
                  <label style={labelStyle}>Card Number</label>
                  <input type="text" name="cardNumber" placeholder="1234 5678 9012 3456" value={paymentDetails.cardNumber} onChange={handleChange} style={inputStyle} required />
                </div>
              </div>
              <div style={{ ...formRow, gridTemplateColumns: '1fr 1fr' }}>
                <div style={formGroup}>
                  <label style={labelStyle}>Expiry Date</label>
                  <input type="text" name="expiry" placeholder="MM/YY" value={paymentDetails.expiry} onChange={handleChange} style={inputStyle} required />
                </div>
                <div style={formGroup}>
                  <label style={labelStyle}>CVV</label>
                  <input type="text" name="cvv" placeholder="123" value={paymentDetails.cvv} onChange={handleChange} style={inputStyle} required />
                </div>
              </div>
              <button type="submit" disabled={loading} style={{ ...payBtn, opacity: loading ? 0.7 : 1 }}>
                {loading ? 'Processing...' : 'Complete Payment'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

/* ======= Styles ======= */
const pageStyle        = { fontFamily: "'Poppins', sans-serif", background: 'linear-gradient(135deg, #001f4d, #4fc3f7)', minHeight: '100vh', paddingBottom: '50px' };
const headerStyle      = { backgroundColor: 'white', padding: '20px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', marginBottom: '30px' };
const headerContent    = { display: 'flex', justifyContent: 'space-between', alignItems: 'center', maxWidth: '1200px', margin: '0 auto' };
const backBtn          = { fontSize: '18px', cursor: 'pointer', color: '#001f4d', fontWeight: '500' };
const headerTitle      = { fontSize: '24px', fontWeight: 'bold', color: '#001f4d', margin: 0 };
const paymentContainer = { maxWidth: '900px', margin: '0 auto', padding: '0 20px' };
const errorBox         = { background: '#ffe0e0', color: '#c00', padding: '12px 16px', borderRadius: '8px', marginBottom: '20px', fontWeight: 'bold' };
const content          = { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px' };
const summarySection   = { backgroundColor: 'white', borderRadius: '15px', padding: '30px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)' };
const summaryTitle     = { fontSize: '20px', fontWeight: 'bold', color: '#001f4d', marginTop: 0, marginBottom: '20px' };
const itemsList        = { marginBottom: '20px' };
const summaryItem      = { display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingBottom: '15px', marginBottom: '15px', borderBottom: '1px solid #f0f0f0' };
const itemNameStyle    = { fontSize: '15px', fontWeight: '600', color: '#333', margin: '0 0 5px' };
const itemQuantityStyle = { fontSize: '13px', color: '#666', margin: 0 };
const itemTotalStyle   = { fontSize: '16px', fontWeight: 'bold', color: '#001f4d', margin: 0 };
const summaryDivider   = { height: '2px', backgroundColor: '#f0f0f0', marginBottom: '15px' };
const totalRow         = { display: 'flex', justifyContent: 'space-between', alignItems: 'center' };
const totalLabel       = { fontSize: '16px', fontWeight: 'bold', color: '#333' };
const totalAmount      = { fontSize: '24px', fontWeight: 'bold', color: '#001f4d' };
const formSection      = { backgroundColor: 'white', borderRadius: '15px', padding: '30px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)' };
const formTitle        = { fontSize: '20px', fontWeight: 'bold', color: '#001f4d', marginTop: 0, marginBottom: '25px' };
const form             = { display: 'flex', flexDirection: 'column' };
const formRow          = { display: 'grid', gridTemplateColumns: '1fr', gap: '20px', marginBottom: '20px' };
const formGroup        = { display: 'flex', flexDirection: 'column' };
const labelStyle       = { fontSize: '13px', fontWeight: '600', color: '#333', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.5px' };
const inputStyle       = { padding: '12px 15px', border: '1px solid #ddd', borderRadius: '8px', fontSize: '15px', outline: 'none' };
const payBtn           = { background: 'linear-gradient(90deg, #ff8c42, #ff6b35)', color: 'white', border: 'none', padding: '14px 40px', borderRadius: '25px', fontSize: '16px', fontWeight: 'bold', cursor: 'pointer', marginTop: '10px' };

export default Payment;
