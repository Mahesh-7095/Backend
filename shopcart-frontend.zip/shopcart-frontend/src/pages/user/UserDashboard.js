import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import api from '../../services/api';

const UserDashboard = () => {
  const navigate = useNavigate();
  const { getCartCount } = useCart();
  const { user, logout } = useAuth();

  const [activeMenu, setActiveMenu] = useState('account');
  const [profile, setProfile]       = useState(null);
  const [orders, setOrders]         = useState([]);
  const [saving, setSaving]         = useState(false);
  const [message, setMessage]       = useState('');

  /* ── Address form ─────────────────────────────────────────────────────── */
  const [address, setAddress] = useState({ address: '', city: '', state: '', zipCode: '' });

  /* ── Password form ────────────────────────────────────────────────────── */
  const [passwords, setPasswords] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });

  /* ── Load profile + orders on mount ──────────────────────────────────── */
  useEffect(() => {
    if (!user?.userId) return;

    api.get(`/users/${user.userId}`)
      .then((res) => {
        const d = res.data.data;
        setProfile(d);
        setAddress({ address: d.address || '', city: d.city || '', state: d.state || '', zipCode: d.zipCode || '' });
      })
      .catch(() => {
        // Fallback: use data from AuthContext
        setProfile({ fullName: user.fullName, email: user.email, phone: '' });
      });

    api.get(`/orders/user/${user.userId}`)
      .then((res) => setOrders(res.data.data || []))
      .catch(() => setOrders([]));
  }, [user]);

  const showMsg = (msg) => {
    setMessage(msg);
    setTimeout(() => setMessage(''), 3000);
  };

  /* ── Save profile ─────────────────────────────────────────────────────── */
  const handleSaveProfile = async () => {
    setSaving(true);
    try {
      const res = await api.put(`/users/${user.userId}/profile`, {
        fullName: profile.fullName,
        email:    profile.email,
        phone:    profile.phone,
        password: 'placeholder', // backend only updates fullName + phone
      });
      setProfile(res.data.data);
      showMsg('Profile updated successfully!');
    } catch (err) {
      showMsg(err.response?.data?.message || 'Update failed.');
    } finally {
      setSaving(false);
    }
  };

  /* ── Save address ─────────────────────────────────────────────────────── */
  const handleSaveAddress = async () => {
    setSaving(true);
    try {
      const res = await api.patch(`/users/${user.userId}/address`, address);
      const d = res.data.data;
      setAddress({ address: d.address || '', city: d.city || '', state: d.state || '', zipCode: d.zipCode || '' });
      showMsg('Address saved successfully!');
    } catch (err) {
      showMsg(err.response?.data?.message || 'Save failed.');
    } finally {
      setSaving(false);
    }
  };

  /* ── Change password ──────────────────────────────────────────────────── */
  const handleChangePassword = async () => {
    if (passwords.newPassword !== passwords.confirmPassword) {
      showMsg('New passwords do not match.');
      return;
    }
    setSaving(true);
    try {
      await api.patch(`/users/${user.userId}/password`, {
        currentPassword: passwords.currentPassword,
        newPassword:     passwords.newPassword,
      });
      showMsg('Password changed successfully!');
      setPasswords({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch (err) {
      showMsg(err.response?.data?.message || 'Password change failed.');
    } finally {
      setSaving(false);
    }
  };

  /* ── Logout ───────────────────────────────────────────────────────────── */
  const handleSignOut = async () => {
    await logout();
    navigate('/login');
  };

  const menuItems = [
    { id: 'account',  label: 'My Account',      icon: '👤' },
    { id: 'password', label: 'Change Password',  icon: '🔐' },
    { id: 'address',  label: 'Address',          icon: '📍' },
    { id: 'orders',   label: 'Orders',           icon: '📦' },
  ];

  const initials = profile?.fullName
    ? profile.fullName.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2)
    : (user?.fullName?.slice(0, 2).toUpperCase() || 'U');

  const getStatusBadge = (status) => {
    const colors = { PROCESSING: '#ffa726', SHIPPED: '#66bb6a', DELIVERED: '#29b6f6', CANCELLED: '#ef5350' };
    return { backgroundColor: colors[status] || '#4fc3f7', color: 'white', padding: '6px 14px', borderRadius: '20px', fontSize: '12px', fontWeight: 'bold' };
  };

  return (
    <div style={pageStyle}>
      {/* Header */}
      <header style={headerStyle}>
        <div style={headerContent}>
          <div style={logoStyle}>🛒 <span style={{ color: '#001f4d', fontWeight: 'bold' }}>Shopcart</span></div>
          <div style={headerRight}>
            <div style={searchBar}><input type="text" placeholder="Search Product" style={searchInput} /><button style={searchBtn}>🔍</button></div>
            <span style={icon} onClick={() => navigate('/user-home')}>🏠</span>
            <span style={icon} onClick={() => navigate('/cart')}>🛒 ({getCartCount()})</span>
          </div>
        </div>
      </header>

      {/* Toast */}
      {message && <div style={toast}>{message}</div>}

      {/* Main Layout */}
      <div style={mainContainer}>
        {/* Sidebar */}
        <aside style={sidebar}>
          <div style={profileSection}>
            <div style={avatar}><span style={avatarText}>{initials}</span></div>
            <h3 style={userName}>{profile?.fullName || user?.fullName || 'User'}</h3>
            <p style={{ color: '#888', fontSize: '13px', margin: 0 }}>{profile?.email || user?.email}</p>
          </div>
          <nav style={navMenu}>
            {menuItems.map((item) => (
              <div
                key={item.id}
                style={activeMenu === item.id ? { ...menuItem, ...menuItemActive } : menuItem}
                onClick={() => setActiveMenu(item.id)}
              >
                <span style={menuIcon}>{item.icon}</span>
                <span style={menuLabel}>{item.label}</span>
              </div>
            ))}
            <div style={menuItem} onClick={handleSignOut}>
              <span style={menuIcon}>🚪</span>
              <span style={menuLabel}>Sign Out</span>
            </div>
          </nav>
        </aside>

        {/* Content */}
        <main style={mainContent}>

          {/* ── My Account ───────────────────────────────────────────────── */}
          {activeMenu === 'account' && profile && (
            <div>
              <h2 style={formTitle}>My Account</h2>
              <div style={formRow}>
                <div style={formGroup}>
                  <label style={label}>Full Name</label>
                  <input style={input} value={profile.fullName || ''} onChange={(e) => setProfile({ ...profile, fullName: e.target.value })} />
                </div>
                <div style={formGroup}>
                  <label style={label}>Phone Number</label>
                  <input style={input} value={profile.phone || ''} onChange={(e) => setProfile({ ...profile, phone: e.target.value })} />
                </div>
              </div>
              <div style={formRow}>
                <div style={formGroup}>
                  <label style={label}>Email</label>
                  <input style={{ ...input, backgroundColor: '#f5f5f5' }} value={profile.email || ''} readOnly />
                </div>
                <div style={formGroup}>
                  <label style={label}>Role</label>
                  <input style={{ ...input, backgroundColor: '#f5f5f5' }} value={profile.role || 'USER'} readOnly />
                </div>
              </div>
              <button style={changeBtn} onClick={handleSaveProfile} disabled={saving}>
                {saving ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          )}

          {/* ── Change Password ───────────────────────────────────────────── */}
          {activeMenu === 'password' && (
            <div>
              <h2 style={formTitle}>Change Password</h2>
              {[
                { key: 'currentPassword', label: 'Current Password' },
                { key: 'newPassword',     label: 'New Password' },
                { key: 'confirmPassword', label: 'Confirm New Password' },
              ].map((f) => (
                <div key={f.key} style={{ ...formRow, gridTemplateColumns: '1fr' }}>
                  <div style={formGroup}>
                    <label style={label}>{f.label}</label>
                    <input
                      type="password"
                      style={input}
                      value={passwords[f.key]}
                      onChange={(e) => setPasswords({ ...passwords, [f.key]: e.target.value })}
                    />
                  </div>
                </div>
              ))}
              <button style={changeBtn} onClick={handleChangePassword} disabled={saving}>
                {saving ? 'Updating...' : 'Update Password'}
              </button>
            </div>
          )}

          {/* ── Address ──────────────────────────────────────────────────── */}
          {activeMenu === 'address' && (
            <div>
              <h2 style={formTitle}>My Address</h2>
              <div style={formRow}>
                <div style={formGroup}>
                  <label style={label}>Street Address</label>
                  <input style={input} value={address.address} placeholder="Enter street address" onChange={(e) => setAddress({ ...address, address: e.target.value })} />
                </div>
                <div style={formGroup}>
                  <label style={label}>City</label>
                  <input style={input} value={address.city} placeholder="Enter city" onChange={(e) => setAddress({ ...address, city: e.target.value })} />
                </div>
              </div>
              <div style={formRow}>
                <div style={formGroup}>
                  <label style={label}>State</label>
                  <input style={input} value={address.state} placeholder="Enter state" onChange={(e) => setAddress({ ...address, state: e.target.value })} />
                </div>
                <div style={formGroup}>
                  <label style={label}>Zip Code</label>
                  <input style={input} value={address.zipCode} placeholder="Enter zip code" onChange={(e) => setAddress({ ...address, zipCode: e.target.value })} />
                </div>
              </div>
              <button style={changeBtn} onClick={handleSaveAddress} disabled={saving}>
                {saving ? 'Saving...' : 'Save Address'}
              </button>
            </div>
          )}

          {/* ── Orders ───────────────────────────────────────────────────── */}
          {activeMenu === 'orders' && (
            <div>
              <h2 style={formTitle}>My Orders</h2>
              {orders.length === 0 ? (
                <p style={{ color: '#666', fontSize: '16px' }}>
                  No orders yet. <span style={{ color: '#001f4d', cursor: 'pointer' }} onClick={() => navigate('/user-home')}>Start shopping</span>
                </p>
              ) : (
                <div style={ordersGrid}>
                  {orders.map((order) => (
                    <div key={order.id} style={orderCard}>
                      <div style={orderHeader}>
                        <div>
                          <p style={orderNumber}>Order #{order.id}</p>
                          <p style={orderDate}>{new Date(order.orderedAt).toLocaleDateString('en-IN')}</p>
                        </div>
                        <span style={getStatusBadge(order.status)}>{order.status}</span>
                      </div>
                      <div style={orderDivider} />
                      <div>
                        <p style={itemsLabel}>Items ({order.items?.length || 0})</p>
                        {order.items?.map((item, i) => (
                          <p key={i} style={itemLine}>{item.name} × {item.quantity}</p>
                        ))}
                      </div>
                      <div style={orderDivider} />
                      <div style={orderFooter}>
                        <p style={totalLabel}>Total</p>
                        <p style={totalAmount}>₹{Number(order.totalAmount).toLocaleString('en-IN')}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </main>
      </div>
    </div>
  );
};

/* ======= Styles ======= */
const pageStyle      = { fontFamily: "'Poppins', sans-serif", background: 'linear-gradient(135deg, #001f4d, #4fc3f7)', minHeight: '100vh', paddingBottom: '50px' };
const headerStyle    = { backgroundColor: 'white', padding: '20px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', marginBottom: '30px' };
const headerContent  = { display: 'flex', justifyContent: 'space-between', alignItems: 'center', maxWidth: '1400px', margin: '0 auto' };
const logoStyle      = { fontSize: '24px', fontWeight: 'bold' };
const headerRight    = { display: 'flex', alignItems: 'center', gap: '20px' };
const searchBar      = { display: 'flex', border: '1px solid #ddd', borderRadius: '25px', overflow: 'hidden' };
const searchInput    = { border: 'none', padding: '10px 15px', outline: 'none', width: '200px' };
const searchBtn      = { background: 'linear-gradient(90deg, #001f4d, #4fc3f7)', color: 'white', border: 'none', padding: '10px 15px', cursor: 'pointer' };
const icon           = { fontSize: '20px', cursor: 'pointer' };
const toast          = { position: 'fixed', top: '20px', left: '50%', transform: 'translateX(-50%)', backgroundColor: '#4CAF50', color: 'white', padding: '14px 28px', borderRadius: '8px', fontWeight: 'bold', zIndex: 9999, boxShadow: '0 4px 12px rgba(0,0,0,0.2)' };
const mainContainer  = { display: 'grid', gridTemplateColumns: '280px 1fr', gap: '30px', maxWidth: '1400px', margin: '0 auto', padding: '0 20px' };
const sidebar        = { backgroundColor: 'white', borderRadius: '15px', padding: '30px 20px', boxShadow: '0 4px 12px rgba(0,0,0,0.08)', height: 'fit-content', position: 'sticky', top: '20px' };
const profileSection = { textAlign: 'center', paddingBottom: '25px', borderBottom: '1px solid #f0f0f0' };
const avatar         = { width: '100px', height: '100px', borderRadius: '50%', background: 'linear-gradient(135deg, #001f4d, #4fc3f7)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 15px', boxShadow: '0 4px 12px rgba(0,31,77,0.2)' };
const avatarText     = { fontSize: '36px', fontWeight: 'bold', color: 'white' };
const userName       = { fontSize: '18px', fontWeight: 'bold', color: '#001f4d', margin: '10px 0 0' };
const navMenu        = { marginTop: '20px', display: 'flex', flexDirection: 'column', gap: '5px' };
const menuItem       = { display: 'flex', alignItems: 'center', gap: '12px', padding: '12px 15px', borderRadius: '10px', cursor: 'pointer', color: '#333', fontSize: '15px', fontWeight: '500' };
const menuItemActive = { backgroundColor: '#001f4d', color: 'white', boxShadow: '0 4px 12px rgba(0,31,77,0.2)' };
const menuIcon       = { fontSize: '18px' };
const menuLabel      = { flex: 1 };
const mainContent    = { backgroundColor: 'white', borderRadius: '15px', padding: '40px', boxShadow: '0 4px 12px rgba(0,0,0,0.08)' };
const formTitle      = { fontSize: '28px', fontWeight: 'bold', color: '#001f4d', marginTop: 0, marginBottom: '30px', paddingBottom: '20px', borderBottom: '2px solid #f0f0f0' };
const formRow        = { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px', marginBottom: '25px' };
const formGroup      = { display: 'flex', flexDirection: 'column' };
const label          = { fontSize: '14px', fontWeight: '600', color: '#333', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.5px' };
const input          = { padding: '12px 15px', border: '1px solid #ddd', borderRadius: '8px', fontSize: '15px', outline: 'none' };
const changeBtn      = { background: 'linear-gradient(90deg, #ff8c42, #ff6b35)', color: 'white', border: 'none', padding: '14px 40px', borderRadius: '25px', fontSize: '16px', fontWeight: 'bold', cursor: 'pointer', marginTop: '20px' };
const ordersGrid     = { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))', gap: '20px' };
const orderCard      = { backgroundColor: '#f9f9f9', borderRadius: '12px', padding: '20px', border: '1px solid #e0e0e0' };
const orderHeader    = { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '15px' };
const orderNumber    = { fontSize: '16px', fontWeight: 'bold', color: '#001f4d', margin: '0 0 5px' };
const orderDate      = { fontSize: '13px', color: '#999', margin: 0 };
const orderDivider   = { height: '1px', backgroundColor: '#e0e0e0', margin: '15px 0' };
const itemsLabel     = { fontSize: '13px', fontWeight: 'bold', color: '#333', margin: '0 0 8px' };
const itemLine       = { fontSize: '13px', color: '#666', margin: '5px 0', paddingLeft: '10px' };
const orderFooter    = { display: 'flex', justifyContent: 'space-between', alignItems: 'center' };
const totalLabel     = { fontSize: '14px', fontWeight: 'bold', color: '#333', margin: 0 };
const totalAmount    = { fontSize: '18px', fontWeight: 'bold', color: '#001f4d', margin: 0 };

export default UserDashboard;
