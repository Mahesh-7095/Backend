import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import api from '../../services/api';

const FALLBACK_PRODUCTS = [
  { id: 1,  name: 'Wireless Headphones', price: 2999,  category: 'Electronics', image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=250&h=250&fit=crop', discount: '15%' },
  { id: 2,  name: 'Smartphone',          price: 19999, category: 'Electronics', image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=250&h=250&fit=crop', discount: '15%' },
  { id: 3,  name: 'Laptop',              price: 54999, category: 'Electronics', image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=250&h=250&fit=crop', discount: '10%' },
  { id: 4,  name: 'Running Shoes',       price: 2999,  category: 'Fashion',     image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=250&h=250&fit=crop', discount: '25%' },
  { id: 5,  name: 'Rice 5kg',            price: 299,   category: 'Groceries',   image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=250&h=250&fit=crop', discount: '5%'  },
  { id: 6,  name: 'T-Shirt',             price: 999,   category: 'Cloth',       image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=250&h=250&fit=crop', discount: '20%' },
  { id: 7,  name: 'Smart Watch',         price: 7999,  category: 'Electronics', image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=250&h=250&fit=crop', discount: '15%' },
  { id: 8,  name: 'Milk 1L',             price: 60,    category: 'Groceries',   image: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=250&h=250&fit=crop', discount: '5%'  },
  { id: 9,  name: 'Backpack',            price: 1999,  category: 'Fashion',     image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=250&h=250&fit=crop', discount: '25%' },
  { id: 10, name: 'Gaming Mouse',        price: 1499,  category: 'Electronics', image: 'https://images.unsplash.com/photo-1527814050087-3793815479db?w=250&h=250&fit=crop', discount: '15%' },
  { id: 11, name: 'Notebook',            price: 50,    category: 'Stationary',  image: 'https://images.unsplash.com/photo-1531346878377-a5be20888e57?w=250&h=250&fit=crop', discount: '10%' },
  { id: 12, name: 'Pen Set',             price: 150,   category: 'Stationary',  image: 'https://images.unsplash.com/photo-1583485088034-697b5bc74d37?w=250&h=250&fit=crop', discount: '25%' },
];

const UserHome = () => {
  const navigate = useNavigate();
  const { addToCart, getCartCount } = useCart();
  const { user, logout } = useAuth();

  const [products, setProducts]               = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [loading, setLoading]                 = useState(true);
  const [notification, setNotification]       = useState({ show: false, message: '' });
  const [sortBy, setSortBy]                   = useState('default');
  const [searchTerm, setSearchTerm]           = useState('');

  /* ── Fetch products from backend ───────────────────────────────────────── */
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const res = await api.get('/products');
        const list = res.data.data || [];
        // Normalise: backend sends `image`, frontend used `image`
        setProducts(list.map((p) => ({ ...p, image: p.image || p.imageUrl })));
      } catch {
        setProducts(FALLBACK_PRODUCTS);
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, []);

  /* ── Filter + sort ─────────────────────────────────────────────────────── */
  useEffect(() => {
    let list = selectedCategory === 'All'
      ? [...products]
      : products.filter((p) => p.category === selectedCategory);

    if (searchTerm) {
      list = list.filter((p) => p.name.toLowerCase().includes(searchTerm.toLowerCase()));
    }
    if (sortBy === 'priceLow')  list.sort((a, b) => a.price - b.price);
    if (sortBy === 'priceHigh') list.sort((a, b) => b.price - a.price);
    if (sortBy === 'discount')  list.sort((a, b) => parseInt(b.discount) - parseInt(a.discount));

    setFilteredProducts(list);
  }, [selectedCategory, products, sortBy, searchTerm]);

  const handleAddToCart = (product) => {
    addToCart(product);
    setNotification({ show: true, message: `${product.name} added to cart!` });
    setTimeout(() => setNotification({ show: false, message: '' }), 3000);
  };

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', background: 'linear-gradient(135deg,#001f4d,#4fc3f7)' }}>
        <div style={{ color: 'white', fontSize: '24px', fontWeight: 'bold' }}>Loading products...</div>
      </div>
    );
  }

  const categories = ['All', 'Electronics', 'Stationary', 'Groceries', 'Cloth', 'Fashion'];

  return (
    <div style={pageContainer}>

      {/* Cart Notification */}
      {notification.show && (
        <div style={cartNotification}>
          <span style={notificationText}>{notification.message}</span>
          <span style={notificationClose} onClick={() => setNotification({ show: false, message: '' })}>×</span>
        </div>
      )}

      {/* Top notification bar */}
      <div style={notificationBar}>
        <span>+001234567890</span>
        <span>Get 50% Off on Selected Items | Shop Now</span>
        <div style={notificationRight}>
          <select style={dropdown}><option>Eng</option></select>
          {user && (
            <span style={{ cursor: 'pointer', fontSize: '13px' }} onClick={handleLogout}>
              Logout ({user.fullName?.split(' ')[0]})
            </span>
          )}
        </div>
      </div>

      {/* Main Navbar */}
      <header style={header}>
        <div style={headerContent}>
          <div style={logo}>🛒 <span style={{ color: '#001f4d', fontWeight: 'bold' }}>Shopcart</span></div>
          <div style={headerRight}>
            <div style={searchBar}>
              <input
                type="text"
                placeholder="Search Product"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                style={searchInput}
              />
              <button style={searchBtn}>🔍</button>
            </div>
            <span style={icon} onClick={() => navigate('/user-dashboard')}>👤</span>
            <span style={icon} onClick={() => navigate('/cart')}>🛒 ({getCartCount()})</span>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section style={hero}>
        <div style={heroContent}>
          <div style={heroLeft}>
            <h1 style={heroHeading}>Grab Upto 50% Off On Selected Products</h1>
            <button style={buyNowBtn}>Buy Now</button>
          </div>
          <div style={heroRight}>
            <img
              src="https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=300&fit=crop"
              alt="Hero"
              style={heroImage}
            />
          </div>
        </div>
      </section>

      {/* Filter Bar */}
      <div style={filterBar}>
        <div style={categoryBubbles}>
          {categories.map((cat) => (
            <span
              key={cat}
              style={selectedCategory === cat ? { ...categoryBubble, ...activeBubble } : categoryBubble}
              onClick={() => setSelectedCategory(cat)}
            >
              {cat === 'All' ? 'All Products' : cat}
            </span>
          ))}
        </div>
        <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} style={sortDropdown}>
          <option value="default">Sort by</option>
          <option value="priceLow">Price Low to High</option>
          <option value="priceHigh">Price High to Low</option>
          <option value="discount">Discount</option>
        </select>
      </div>

      {/* Products Grid */}
      <section style={productSection}>
        <h2 style={sectionTitle}>Products For You!</h2>
        {filteredProducts.length === 0 ? (
          <p style={{ textAlign: 'center', color: 'white', fontSize: '18px' }}>No products found.</p>
        ) : (
          <div style={productGrid}>
            {filteredProducts.map((p) => (
              <div key={p.id} style={productCard}>
                <div style={wishlistIcon}>❤️</div>
                <img src={p.image} alt={p.name} style={productImg} />
                <h3 style={productName}>{p.name}</h3>
                {p.discount && (
                  <div style={discountBadge}>
                    <span style={discountText}>{p.discount} OFF</span>
                  </div>
                )}
                <p style={price}>₹{Number(p.price).toLocaleString('en-IN')}</p>
                <button style={addToCartBtn} onClick={() => handleAddToCart(p)}>Add to Cart</button>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};

/* ======= Styles ======= */
const pageContainer    = { fontFamily: "'Poppins', sans-serif", background: 'linear-gradient(135deg, #001f4d, #4fc3f7)', minHeight: '100vh' };
const notificationBar  = { background: 'linear-gradient(90deg, #001f4d, #4fc3f7)', color: 'white', padding: '10px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '14px' };
const notificationRight = { display: 'flex', alignItems: 'center', gap: '15px' };
const dropdown         = { backgroundColor: 'transparent', color: 'white', border: '1px solid white', padding: '5px', borderRadius: '4px' };
const header           = { backgroundColor: 'white', padding: '20px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', marginBottom: '30px' };
const headerContent    = { display: 'flex', justifyContent: 'space-between', alignItems: 'center', maxWidth: '1200px', margin: '0 auto' };
const logo             = { fontSize: '24px', fontWeight: 'bold' };
const headerRight      = { display: 'flex', alignItems: 'center', gap: '20px' };
const searchBar        = { display: 'flex', border: '1px solid #ddd', borderRadius: '25px', overflow: 'hidden' };
const searchInput      = { border: 'none', padding: '10px 15px', outline: 'none', flex: 1 };
const searchBtn        = { background: 'linear-gradient(90deg, #001f4d, #4fc3f7)', color: 'white', border: 'none', padding: '10px 15px', cursor: 'pointer' };
const icon             = { fontSize: '20px', cursor: 'pointer' };
const hero             = { backgroundColor: '#F5F5DC', borderRadius: '20px', padding: '50px 30px', marginBottom: '30px', maxWidth: '1200px', margin: '0 auto 30px', display: 'flex', alignItems: 'center' };
const heroContent      = { display: 'flex', width: '100%', alignItems: 'center' };
const heroLeft         = { flex: 1, paddingRight: '50px' };
const heroHeading      = { fontSize: '48px', fontWeight: 'bold', color: '#666', marginBottom: '20px', lineHeight: '1.2' };
const buyNowBtn        = { background: 'linear-gradient(90deg, #001f4d, #4fc3f7)', color: 'white', border: 'none', padding: '15px 30px', borderRadius: '25px', fontSize: '18px', fontWeight: 'bold', cursor: 'pointer' };
const heroRight        = { flex: 1, textAlign: 'center' };
const heroImage        = { maxWidth: '100%', borderRadius: '20px' };
const filterBar        = { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '20px', maxWidth: '1200px', margin: '0 auto 30px' };
const categoryBubbles  = { display: 'flex', gap: '10px', flexWrap: 'wrap' };
const categoryBubble   = { backgroundColor: 'white', padding: '8px 16px', borderRadius: '20px', border: '1px solid #ddd', cursor: 'pointer', fontSize: '14px', whiteSpace: 'nowrap' };
const activeBubble     = { backgroundColor: '#001f4d', color: 'white', border: '1px solid #001f4d' };
const sortDropdown     = { padding: '10px 15px', border: '1px solid #ddd', borderRadius: '5px', backgroundColor: 'white' };
const productSection   = { maxWidth: '1200px', margin: '0 auto', padding: '0 20px 50px' };
const sectionTitle     = { fontSize: '32px', fontWeight: 'bold', color: '#001f4d', textAlign: 'center', marginBottom: '40px' };
const productGrid      = { display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '30px' };
const productCard      = { backgroundColor: 'white', borderRadius: '15px', padding: '20px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)', textAlign: 'center', position: 'relative' };
const wishlistIcon     = { position: 'absolute', top: '15px', right: '15px', fontSize: '20px', cursor: 'pointer' };
const productImg       = { width: '100%', height: '200px', objectFit: 'cover', borderRadius: '10px', marginBottom: '15px' };
const productName      = { fontSize: '18px', fontWeight: 'bold', color: '#333', marginBottom: '5px' };
const price            = { fontSize: '20px', fontWeight: 'bold', color: '#001f4d', marginBottom: '15px' };
const discountBadge    = { marginBottom: '10px' };
const discountText     = { backgroundColor: '#ff4444', color: 'white', padding: '5px 10px', borderRadius: '15px', fontSize: '12px', fontWeight: 'bold' };
const addToCartBtn     = { background: 'linear-gradient(90deg, #001f4d, #4fc3f7)', color: 'white', border: 'none', padding: '12px 24px', borderRadius: '25px', fontSize: '16px', fontWeight: 'bold', cursor: 'pointer', width: '100%' };
const cartNotification = { position: 'fixed', top: '20px', right: '20px', backgroundColor: '#4CAF50', color: 'white', padding: '15px 20px', borderRadius: '8px', boxShadow: '0 4px 8px rgba(0,0,0,0.2)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'space-between', minWidth: '300px' };
const notificationText = { fontSize: '16px', fontWeight: 'bold' };
const notificationClose = { fontSize: '24px', cursor: 'pointer', marginLeft: '15px', fontWeight: 'bold' };

export default UserHome;
