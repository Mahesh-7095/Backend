export const adminTheme = {
  primary: "#0d47a1",
  dashboardBg: "#f5f5f5",
  cardBg: "#ffffff",
  textPrimary: "#333333",
  textSecondary: "#666666",
  accentColor: "#29b6f6"
};
